import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { HeroSection } from './components/HeroSection';
import { BusSearch } from './components/BusSearch';
import { BusResults } from './components/BusResults';
import { LiveBusTracking } from './components/LiveBusTracking';
import { SeatBooking } from './components/SeatBooking';
import { BookingConfirmation } from './components/BookingConfirmation';
import { DigitalTicket } from './components/DigitalTicket';
import { ConductorDashboard } from './components/ConductorDashboard';
import { SafetyCenter } from './components/SafetyCenter';
import { WomenSafetyMode } from './components/WomenSafetyMode';
import { MyTickets } from './components/MyTickets';
import { MyTrips } from './components/MyTrips';
import { AdminDashboard } from './components/AdminDashboard';
import { BusDetailsModal } from './components/BusDetailsModal';
import { SOSModal } from './components/SOSModal';
import { ReportIssueModal } from './components/ReportIssueModal';
import { LostAndFoundModal } from './components/LostAndFoundModal';
import { ProfileModal } from './components/ProfileModal';
import { DestinationAlertModal } from './components/DestinationAlertModal';
import { Future2030Features } from './components/Future2030Features';
import { Bus } from './types';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

const MainContent: React.FC = () => {
  const { 
    activeView, 
    setActiveView, 
    selectedBus, 
    setSelectedBus, 
    lastConfirmedBooking,
    performSearch,
    toastMessage
  } = useApp();

  // Booking Flow Steps: 'seat-select' | 'confirm-pay' | 'ticket-pass'
  const [bookingStep, setBookingStep] = useState<'seat-select' | 'confirm-pay' | 'ticket-pass'>('seat-select');
  const [selectedSeatForBooking, setSelectedSeatForBooking] = useState<string | null>(null);

  // Modals state
  const [inspectedBusForDetails, setInspectedBusForDetails] = useState<Bus | null>(null);
  const [sosModalOpen, setSosModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [lostFoundModalOpen, setLostFoundModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [futureFeaturesOpen, setFutureFeaturesOpen] = useState(false);

  const handleStartBooking = (bus: Bus) => {
    setSelectedBus(bus);
    setSelectedSeatForBooking(null);
    setBookingStep('seat-select');
    setActiveView('booking-flow');
  };

  const handleLiveTrackFromCard = (bus: Bus) => {
    setSelectedBus(bus);
    setActiveView('live');
  };

  const handleRebookRoute = (from: string, to: string) => {
    performSearch(from, to, new Date().toISOString().split('T')[0], '18:30');
    setActiveView('search');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-between selection:bg-blue-600 selection:text-white pb-16 lg:pb-0">
      
      {/* Toast Notification Bar */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 max-w-sm animate-bounce-short">
          <div className={`p-4 rounded-2xl shadow-xl border flex items-center gap-3 text-xs font-bold ${
            toastMessage.type === 'error'
              ? 'bg-red-600 text-white border-red-500'
              : toastMessage.type === 'success'
              ? 'bg-emerald-600 text-white border-emerald-500'
              : 'bg-slate-900 text-white border-slate-800'
          }`}>
            {toastMessage.type === 'error' && <AlertCircle size={18} className="shrink-0" />}
            {toastMessage.type === 'success' && <CheckCircle2 size={18} className="shrink-0" />}
            {toastMessage.type === 'info' && <Info size={18} className="shrink-0 text-blue-400" />}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        onOpenProfile={() => setProfileModalOpen(true)}
        onOpenSOSModal={() => setSosModalOpen(true)}
        onOpenReportModal={() => setReportModalOpen(true)}
      />

      {/* Main View Router */}
      <main className="grow">
        {/* VIEW: HOME */}
        {activeView === 'home' && (
          <div>
            <HeroSection />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
              <BusSearch />
              <BusResults
                onSelectBusToBook={handleStartBooking}
                onViewBusDetails={(b) => setInspectedBusForDetails(b)}
                onLiveTrackBus={handleLiveTrackFromCard}
              />
            </div>
          </div>
        )}

        {/* VIEW: SEARCH BUSES */}
        {activeView === 'search' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
            <BusSearch />
            <BusResults
              onSelectBusToBook={handleStartBooking}
              onViewBusDetails={(b) => setInspectedBusForDetails(b)}
              onLiveTrackBus={handleLiveTrackFromCard}
            />
          </div>
        )}

        {/* VIEW: LIVE BUS TRACKING */}
        {activeView === 'live' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <LiveBusTracking
              onSelectBusToBook={handleStartBooking}
            />
          </div>
        )}

        {/* VIEW: MY TICKETS */}
        {activeView === 'tickets' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <MyTickets
              onBookNewTrip={() => setActiveView('search')}
              onLiveTrackBus={(busId) => {
                const b = selectedBus;
                if (b) setSelectedBus(b);
                setActiveView('live');
              }}
            />
          </div>
        )}

        {/* VIEW: MY TRIPS */}
        {activeView === 'trips' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <MyTrips onRebookRoute={handleRebookRoute} />
          </div>
        )}

        {/* VIEW: SAFETY CENTER */}
        {activeView === 'safety' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <SafetyCenter
              onOpenSOSModal={() => setSosModalOpen(true)}
              onOpenReportModal={() => setReportModalOpen(true)}
            />
          </div>
        )}

        {/* VIEW: WOMEN SAFETY MODE */}
        {activeView === 'women-safety' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <WomenSafetyMode
              onOpenSOSModal={() => setSosModalOpen(true)}
            />
          </div>
        )}

        {/* VIEW: CONDUCTOR DASHBOARD */}
        {activeView === 'conductor' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <ConductorDashboard />
          </div>
        )}

        {/* VIEW: ADMIN PANEL */}
        {activeView === 'admin' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <AdminDashboard />
          </div>
        )}

        {/* VIEW: BOOKING FLOW */}
        {activeView === 'booking-flow' && selectedBus && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {bookingStep === 'seat-select' && (
              <SeatBooking
                bus={selectedBus}
                onBack={() => setActiveView('search')}
                onProceedToConfirm={(seatNum) => {
                  setSelectedSeatForBooking(seatNum);
                  setBookingStep('confirm-pay');
                }}
              />
            )}

            {bookingStep === 'confirm-pay' && selectedSeatForBooking && (
              <BookingConfirmation
                bus={selectedBus}
                seatNumber={selectedSeatForBooking}
                onBack={() => setBookingStep('seat-select')}
                onBookingSuccess={() => setBookingStep('ticket-pass')}
              />
            )}

            {bookingStep === 'ticket-pass' && lastConfirmedBooking && (
              <DigitalTicket
                booking={lastConfirmedBooking}
                onNavigateToLive={() => setActiveView('live')}
                onNavigateToMyTickets={() => setActiveView('tickets')}
              />
            )}
          </div>
        )}
      </main>

      {/* Global Footer */}
      <footer className="bg-white border-t border-slate-200 mt-16 text-xs text-slate-500 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="font-extrabold text-slate-900">SmartBus Transport System</span>
            <span>• Safe & Smart Public Commute</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 font-semibold text-slate-600">
            <button onClick={() => setFutureFeaturesOpen(true)} className="hover:text-blue-600 transition">
              2030 Vision
            </button>
            <button onClick={() => setReportModalOpen(true)} className="hover:text-blue-600 transition">
              Report Problem
            </button>
            <button onClick={() => setLostFoundModalOpen(true)} className="hover:text-blue-600 transition">
              Lost & Found
            </button>
            <button onClick={() => setSosModalOpen(true)} className="text-red-600 hover:underline font-bold">
              SOS Helpline (112)
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Bar */}
      <BottomNav onOpenProfile={() => setProfileModalOpen(true)} />

      {/* Modals */}
      {inspectedBusForDetails && (
        <BusDetailsModal
          bus={inspectedBusForDetails}
          onClose={() => setInspectedBusForDetails(null)}
          onBookSeat={(bus) => {
            setInspectedBusForDetails(null);
            handleStartBooking(bus);
          }}
        />
      )}

      {sosModalOpen && (
        <SOSModal onClose={() => setSosModalOpen(false)} />
      )}

      {reportModalOpen && (
        <ReportIssueModal
          onClose={() => setReportModalOpen(false)}
          onOpenLostFound={() => setLostFoundModalOpen(true)}
        />
      )}

      {lostFoundModalOpen && (
        <LostAndFoundModal onClose={() => setLostFoundModalOpen(false)} />
      )}

      {profileModalOpen && (
        <ProfileModal
          onClose={() => setProfileModalOpen(false)}
          onOpenFutureFeatures={() => setFutureFeaturesOpen(true)}
        />
      )}

      {futureFeaturesOpen && (
        <Future2030Features onClose={() => setFutureFeaturesOpen(false)} />
      )}

      {/* Destination Proximity Alert Notification Modal */}
      <DestinationAlertModal />

    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

export default App;
