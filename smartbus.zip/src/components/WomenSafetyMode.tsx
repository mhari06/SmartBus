import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  HeartHandshake, 
  ShieldCheck, 
  Moon, 
  Bell, 
  CheckCircle2, 
  AlertCircle, 
  PhoneCall, 
  MapPin, 
  Armchair,
  Sparkles,
  Users
} from 'lucide-react';

interface WomenSafetyModeProps {
  onOpenSOSModal: () => void;
}

export const WomenSafetyMode: React.FC<WomenSafetyModeProps> = ({ onOpenSOSModal }) => {
  const { 
    userProfile, 
    updateUserProfile, 
    buses, 
    isSafetyCheckInActive, 
    setIsSafetyCheckInActive, 
    acknowledgeSafetyCheckIn,
    showToast 
  } = useApp();

  const [testCheckInShown, setTestCheckInShown] = useState(false);

  const handleToggleWomenSafety = () => {
    const next = !userProfile.womenSafetyMode;
    updateUserProfile({ womenSafetyMode: next });
    showToast(next ? 'Women Safety Mode Activated 🌸' : 'Women Safety Mode Deactivated', 'info');
  };

  const handleTriggerDemoCheckIn = () => {
    setIsSafetyCheckInActive(true);
    setTestCheckInShown(true);
  };

  return (
    <div className="space-y-8">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-br from-pink-600 via-rose-600 to-purple-700 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider">
              <HeartHandshake size={14} />
              <span>Dedicated Women Transit Safety System</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Women Safety Mode
            </h2>
            <p className="text-xs sm:text-sm text-pink-100 max-w-xl">
              Proactive check-ins before destination stops, priority front seating, night travel safety guidance, and one-touch guardian alerts.
            </p>
          </div>

          {/* Toggle Switch */}
          <div className="bg-white/15 backdrop-blur-md p-4 rounded-2xl border border-white/20 flex items-center justify-between gap-4 w-full md:w-auto">
            <div>
              <p className="font-extrabold text-sm text-white">Mode Status</p>
              <p className="text-[11px] text-pink-200">{userProfile.womenSafetyMode ? 'Protection Active' : 'Disabled'}</p>
            </div>

            <button
              id="women-safety-toggle-btn"
              onClick={handleToggleWomenSafety}
              className={`w-14 h-8 rounded-full transition-colors p-1 flex items-center cursor-pointer ${
                userProfile.womenSafetyMode ? 'bg-white justify-end' : 'bg-white/30 justify-start'
              }`}
            >
              <div className={`w-6 h-6 rounded-full shadow-md transition-transform ${
                userProfile.womenSafetyMode ? 'bg-pink-600' : 'bg-white'
              }`}></div>
            </button>
          </div>
        </div>
      </div>

      {/* Safety Check-In Simulation Section (Section 11: Safety Check-in) */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center">
              <Bell size={20} />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Automated Destination Arrival Safety Check-In
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                When your bus reaches 2 stops before your destination, SmartBus prompts a safety confirmation.
              </p>
            </div>
          </div>

          <button
            onClick={handleTriggerDemoCheckIn}
            className="px-3.5 py-1.5 bg-pink-50 hover:bg-pink-100 text-pink-700 border border-pink-200 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            Simulate Check-In Prompt
          </button>
        </div>

        {/* Interactive Check-in Prompt Display */}
        {isSafetyCheckInActive && (
          <div className="bg-gradient-to-r from-pink-50 to-purple-50 border-2 border-pink-400 p-5 rounded-2xl space-y-3 animate-pulse-slow">
            <div className="flex items-center gap-2 text-pink-900 font-black text-sm">
              <HeartHandshake size={18} className="text-pink-600" />
              <span>Your destination (Guindy Kathipara) is approaching in 2 stops. Are you safe?</span>
            </div>
            <p className="text-xs text-pink-800 font-medium">
              Please respond within 60 seconds. If "Need Help" is tapped or no response is given, emergency contacts and transport control are automatically alerted with your GPS location.
            </p>

            <div className="flex gap-3 pt-2">
              <button
                id="checkin-safe-btn"
                onClick={() => acknowledgeSafetyCheckIn(true)}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 size={16} />
                <span>I'm Safe ✅</span>
              </button>

              <button
                id="checkin-help-btn"
                onClick={() => acknowledgeSafetyCheckIn(false)}
                className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5 cursor-pointer"
              >
                <AlertCircle size={16} />
                <span>Need Help / Trigger Alert 🚨</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3 Pillars of Women Safety */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Pillar 1 */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Armchair size={20} />
          </div>
          <h4 className="font-extrabold text-base text-slate-900">Women Priority Seating</h4>
          <p className="text-xs text-slate-500 leading-relaxed">
            Rows A & B in all SmartBus fleet coaches are reserved exclusively for women passengers, placed in direct line of sight of the driver and emergency panic switches.
          </p>
        </div>

        {/* Pillar 2 */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Moon size={20} />
          </div>
          <h4 className="font-extrabold text-base text-slate-900">Night Travel Safe Corridors</h4>
          <p className="text-xs text-slate-500 leading-relaxed">
            Late evening routes (after 8:00 PM) prioritize drop-offs at well-lit junctions, high-density metro interchanges, and police assistance booths.
          </p>
        </div>

        {/* Pillar 3 */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <ShieldCheck size={20} />
          </div>
          <h4 className="font-extrabold text-base text-slate-900">Guardian SMS Relay</h4>
          <p className="text-xs text-slate-500 leading-relaxed">
            Your emergency contact ({userProfile.emergencyContact.name}) receives automated boarding notifications and destination arrival verification.
          </p>
        </div>

      </div>

      {/* Safe Rated Buses in Fleet */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="font-extrabold text-base text-slate-900">
          Women Safety Certified Buses in Network
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {buses.map((b) => (
            <div key={b.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex justify-between items-center">
              <div>
                <p className="font-black text-slate-900 text-sm">Bus {b.busNumber}</p>
                <p className="text-xs text-slate-500">{b.fromLocation} → {b.toLocation}</p>
                <span className="text-[10px] font-bold text-pink-700 bg-pink-100 px-2 py-0.5 rounded-full inline-block mt-1">
                  ★ Safety Score: {b.safetyRating}/5.0
                </span>
              </div>

              <div className="text-right">
                <span className="text-xs font-bold text-emerald-600 block">{b.availableSeats} Seats</span>
                <span className="text-[10px] text-slate-400">CCTV Equipped</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
