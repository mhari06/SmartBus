import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  History, 
  Leaf, 
  MapPin, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  Bus as BusIcon,
  RotateCcw
} from 'lucide-react';

interface MyTripsProps {
  onRebookRoute: (from: string, to: string) => void;
}

export const MyTrips: React.FC<MyTripsProps> = ({ onRebookRoute }) => {
  const { myTrips } = useApp();

  const totalCarbonSaved = myTrips.reduce((sum, item) => sum + (item.carbonSavedKg || 1.4), 0);
  const totalMoneySpent = myTrips.reduce((sum, item) => sum + item.fare, 0);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <History size={24} className="text-blue-600" />
            <span>Trip History & Eco Mobility Stats</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Review completed journeys, receipts, and environmental impact
          </p>
        </div>
      </div>

      {/* 2030 Eco Impact & Carbon Savings Card */}
      <div className="bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-700 text-white rounded-3xl p-6 sm:p-7 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-56 h-56 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase">
              <Leaf size={14} />
              <span>Smart Mobility Carbon Tracker</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black">
              {totalCarbonSaved.toFixed(1)} kg CO₂ Emissions Saved
            </h3>
            <p className="text-xs text-emerald-100 max-w-md">
              By taking SmartBus over personal private fossil-fuel cars, you actively reduced urban traffic and carbon footprint in Chennai.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 bg-white/15 backdrop-blur-md p-3.5 rounded-2xl border border-white/20 text-center shrink-0 w-full sm:w-auto">
            <div>
              <p className="text-[10px] text-emerald-200 uppercase font-bold">Total Trips</p>
              <p className="text-xl font-black text-white">{myTrips.length}</p>
            </div>
            <div className="border-l border-white/20 pl-3">
              <p className="text-[10px] text-emerald-200 uppercase font-bold">Total Spent</p>
              <p className="text-xl font-black text-white">₹{totalMoneySpent}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Trips Timeline */}
      <div className="space-y-4">
        <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider">
          Past Completed Journeys
        </h3>

        <div className="grid grid-cols-1 gap-3.5">
          {myTrips.map((trip) => (
            <div
              key={trip.id}
              className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-2xl bg-slate-100 text-slate-700 font-black text-sm flex items-center justify-center shrink-0">
                  {trip.busNumber}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-sm sm:text-base text-slate-900">
                      {trip.fromLocation} → {trip.toLocation}
                    </h4>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                      {trip.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {trip.date} • Seat {trip.seatNumber} • Fare: ₹{trip.fare}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                <div className="text-right">
                  <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                    <Leaf size={12} /> -{trip.carbonSavedKg} kg CO₂
                  </span>
                </div>

                <button
                  onClick={() => onRebookRoute(trip.fromLocation, trip.toLocation)}
                  className="px-4 py-2 bg-slate-50 hover:bg-blue-50 hover:text-blue-600 border border-slate-200 hover:border-blue-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1"
                >
                  <RotateCcw size={12} />
                  <span>Book Again</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
