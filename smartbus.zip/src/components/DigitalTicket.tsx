import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Booking } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import { 
  CheckCircle2, 
  Share2, 
  Download, 
  Bell, 
  MapPin, 
  Clock, 
  Armchair, 
  ShieldCheck, 
  Sparkles, 
  Maximize2,
  Copy,
  Bus as BusIcon,
  Navigation
} from 'lucide-react';

interface DigitalTicketProps {
  booking: Booking;
  onNavigateToLive: () => void;
  onNavigateToMyTickets: () => void;
}

export const DigitalTicket: React.FC<DigitalTicketProps> = ({ 
  booking, 
  onNavigateToLive,
  onNavigateToMyTickets 
}) => {
  const { setDestinationAlert, showToast } = useApp();
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleShareTrip = () => {
    const shareUrl = `${window.location.origin}/#ticket=${booking.bookingId}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    showToast('Live Trip & Ticket sharing link copied to clipboard! 📋', 'success');
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleActivateAlert = () => {
    setDestinationAlert(booking.busNumber, booking.toLocation);
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      
      {/* Confirmed Banner */}
      <div className="bg-emerald-500 text-white p-5 rounded-3xl shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight">Booking Confirmed!</h2>
            <p className="text-xs text-emerald-100 font-medium">Digital QR boarding pass is ready.</p>
          </div>
        </div>

        <span className="text-xs font-mono font-bold bg-white text-emerald-800 px-3 py-1 rounded-full shadow-xs">
          {booking.bookingId}
        </span>
      </div>

      {/* Main Digital Ticket Pass Card */}
      <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-xl print:border-none print:shadow-none">
        
        {/* Ticket Header */}
        <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 text-white p-6 relative overflow-hidden">
          <div className="absolute right-0 top-0 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>

          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-blue-200 font-bold uppercase">
                SMARTBUS TRANSIT PASS
              </span>
              <h3 className="text-2xl font-black text-white mt-0.5 flex items-center gap-2">
                <span>Bus {booking.busNumber}</span>
              </h3>
              <p className="text-xs text-blue-100 font-medium">{booking.fromLocation} → {booking.toLocation}</p>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-bold text-blue-200 block uppercase">Fare Paid</span>
              <span className="text-2xl font-black text-white">₹{booking.fare}</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-blue-100 pt-4 border-t border-blue-500/50 mt-4">
            <span>Passenger: <strong className="text-white">{booking.passengerName}</strong></span>
            <span>Status: <strong className="text-emerald-300">PAID & VALID</strong></span>
          </div>
        </div>

        {/* Notched perforated ticket divider */}
        <div className="relative flex items-center justify-between bg-slate-100 py-1 px-4">
          <div className="w-6 h-6 rounded-full bg-slate-50 -ml-7 border-r border-slate-200"></div>
          <div className="w-full border-b-2 border-dashed border-slate-300 mx-2"></div>
          <div className="w-6 h-6 rounded-full bg-slate-50 -mr-7 border-l border-slate-200"></div>
        </div>

        {/* Ticket Body & QR Code */}
        <div className="p-6 sm:p-7 space-y-6 text-center">
          
          {/* QR Code Container */}
          <div className="inline-block bg-slate-50 p-4 rounded-3xl border border-slate-200 shadow-xs relative group cursor-pointer" onClick={() => setQrModalOpen(true)}>
            <QRCodeSVG
              value={booking.qrPayload}
              size={180}
              level="H"
              includeMargin={true}
              className="mx-auto"
            />
            
            <div className="mt-2 flex items-center justify-center gap-1 text-[11px] font-bold text-blue-600">
              <Maximize2 size={13} />
              <span>Tap to Enlarge for Conductor</span>
            </div>
          </div>

          {/* Core Info Grid */}
          <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-center text-xs">
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Seat</p>
              <p className="text-base font-black text-blue-600 mt-0.5">{booking.seatNumber}</p>
            </div>
            <div className="border-x border-slate-200">
              <p className="text-[10px] text-slate-400 font-bold uppercase">Booking ID</p>
              <p className="text-xs font-mono font-bold text-slate-900 mt-1">{booking.bookingId}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Boarding</p>
              <p className="text-xs font-bold text-emerald-700 mt-1">
                {booking.bookingStatus === 'BOARDED' ? 'Boarded ✅' : 'Ready'}
              </p>
            </div>
          </div>

          {/* Barcode visual */}
          <div className="space-y-1">
            <div className="flex justify-center items-center gap-0.5 h-10 overflow-hidden px-4 opacity-80">
              {[...Array(48)].map((_, i) => (
                <div
                  key={i}
                  className="bg-slate-900 h-full"
                  style={{ width: `${(i % 3 === 0 ? 3 : i % 2 === 0 ? 1 : 2)}px` }}
                ></div>
              ))}
            </div>
            <p className="text-[10px] font-mono text-slate-400">{booking.bookingId} • SMARTBUS SECURITY ENCRYPTED</p>
          </div>

        </div>

        {/* Action Buttons Toolbar */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-bold print:hidden">
          <button
            onClick={handleShareTrip}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-2xl text-slate-700 flex flex-col items-center justify-center gap-1.5 transition"
          >
            <Share2 size={16} className="text-blue-600" />
            <span>{copiedLink ? 'Copied!' : 'Share Trip'}</span>
          </button>

          <button
            onClick={handleActivateAlert}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-2xl text-slate-700 flex flex-col items-center justify-center gap-1.5 transition"
          >
            <Bell size={16} className="text-amber-500" />
            <span>Dest. Alert</span>
          </button>

          <button
            onClick={handlePrint}
            className="p-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-2xl text-slate-700 flex flex-col items-center justify-center gap-1.5 transition"
          >
            <Download size={16} className="text-emerald-600" />
            <span>Save / Print</span>
          </button>

          <button
            onClick={onNavigateToLive}
            className="p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl flex flex-col items-center justify-center gap-1.5 transition shadow-sm"
          >
            <Navigation size={16} />
            <span>Track Bus</span>
          </button>
        </div>

      </div>

      {/* Full QR Modal */}
      {qrModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center space-y-4 shadow-2xl">
            <h3 className="text-lg font-black text-slate-900">Show to Conductor</h3>
            <p className="text-xs text-slate-500">
              Conductor can scan this QR with their conductor mode terminal.
            </p>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 inline-block">
              <QRCodeSVG
                value={booking.qrPayload}
                size={240}
                level="H"
                includeMargin={true}
                className="mx-auto"
              />
            </div>

            <div className="font-mono text-sm font-bold text-slate-800">
              {booking.bookingId}
            </div>

            <button
              onClick={() => setQrModalOpen(false)}
              className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-bold"
            >
              Close QR
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
