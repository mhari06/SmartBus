import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  X, 
  Phone, 
  Mail, 
  Globe, 
  Eye, 
  Sparkles, 
  ShieldCheck, 
  HeartHandshake, 
  Save, 
  CheckCircle2,
  Languages
} from 'lucide-react';
import { SupportedLanguage } from '../types';

interface ProfileModalProps {
  onClose: () => void;
  onOpenFutureFeatures: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ onClose, onOpenFutureFeatures }) => {
  const { userProfile, updateUserProfile, setLanguage, language, showToast } = useApp();

  const [name, setName] = useState(userProfile.name);
  const [phone, setPhone] = useState(userProfile.phone);
  const [email, setEmail] = useState(userProfile.email);
  const [guardianName, setGuardianName] = useState(userProfile.emergencyContact.name);
  const [guardianPhone, setGuardianPhone] = useState(userProfile.emergencyContact.phone);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name,
      phone,
      email,
      emergencyContact: {
        ...userProfile.emergencyContact,
        name: guardianName,
        phone: guardianPhone
      }
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 text-left border border-slate-200">
        
        {/* Header */}
        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-xl shadow-md">
              {name.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">{name}</h2>
              <p className="text-xs text-slate-500 font-medium">{email}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition"
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4 text-xs">
          {/* Passenger Information */}
          <div className="space-y-3">
            <h3 className="font-extrabold text-xs text-slate-700 uppercase tracking-wider">
              Passenger Account Details
            </h3>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Mobile Phone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Email ID</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Emergency Guardian */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <h3 className="font-extrabold text-xs text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck size={15} className="text-emerald-600" />
              <span>Emergency Guardian Setup</span>
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Guardian Name</label>
                <input
                  type="text"
                  value={guardianName}
                  onChange={(e) => setGuardianName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Guardian Phone</label>
                <input
                  type="text"
                  value={guardianPhone}
                  onChange={(e) => setGuardianPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  required
                />
              </div>
            </div>
          </div>

          {/* Accessibility & Language Preferences */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <h3 className="font-extrabold text-xs text-slate-700 uppercase tracking-wider">
              Accessibility & Display
            </h3>

            <div className="space-y-2">
              <label className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-200 cursor-pointer">
                <div>
                  <p className="font-bold text-slate-800">Large Text & High Readability</p>
                  <p className="text-[11px] text-slate-500">Increases font sizing and contrast</p>
                </div>
                <input
                  type="checkbox"
                  checked={userProfile.accessibilityMode}
                  onChange={(e) => updateUserProfile({ accessibilityMode: e.target.checked })}
                  className="w-5 h-5 accent-blue-600 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-200 cursor-pointer">
                <div>
                  <p className="font-bold text-slate-800">Women Safety Mode</p>
                  <p className="text-[11px] text-slate-500">Automatic destination check-ins and priority seating</p>
                </div>
                <input
                  type="checkbox"
                  checked={userProfile.womenSafetyMode}
                  onChange={(e) => updateUserProfile({ womenSafetyMode: e.target.checked })}
                  className="w-5 h-5 accent-pink-600 rounded"
                />
              </label>
            </div>
          </div>

          {/* 2030 Smart Features trigger */}
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenFutureFeatures();
            }}
            className="w-full p-3 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl flex items-center justify-between text-blue-900 font-bold transition hover:bg-blue-100"
          >
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-blue-600" />
              <span>Explore 2030 Smart Transit Features</span>
            </div>
            <span>→</span>
          </button>

          {/* Footer Submit */}
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
            >
              <Save size={14} />
              <span>Save Preferences</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
