import React from 'react';
import { Bus, CrowdPredictionSlot } from '../types';
import { Users, TrendingDown, Sparkles, CheckCircle2, Clock } from 'lucide-react';

interface CrowdPredictorProps {
  bus: Bus;
  onBookRecommended?: () => void;
}

export const CrowdPredictor: React.FC<CrowdPredictorProps> = ({ bus, onBookRecommended }) => {
  const predictions: CrowdPredictionSlot[] = bus.crowdPredictions || [
    { time: '05:30 PM', crowdLevel: 'Medium', percentage: 55 },
    { time: '06:00 PM', crowdLevel: 'High', percentage: 88 },
    { time: '06:30 PM', crowdLevel: 'High', percentage: 92 },
    { time: '07:00 PM', crowdLevel: 'Medium', percentage: 65 },
    { time: '07:30 PM', crowdLevel: 'Low', percentage: 35, isRecommended: true },
    { time: '08:00 PM', crowdLevel: 'Low', percentage: 25 }
  ];

  const getBarColor = (percentage: number) => {
    if (percentage > 70) return 'bg-red-500';
    if (percentage > 40) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const getLevelBadge = (level: string) => {
    if (level === 'High') return 'text-red-700 bg-red-50 border-red-200';
    if (level === 'Medium') return 'text-amber-700 bg-amber-50 border-amber-200';
    return 'text-emerald-700 bg-emerald-50 border-emerald-200';
  };

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div>
          <div className="flex items-center gap-2">
            <Users size={20} className="text-purple-600" />
            <h3 className="text-lg font-black text-slate-900 tracking-tight">
              Crowd Level Analytics & AI Forecast
            </h3>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Hourly passenger density predictions calculated for Route {bus.routeName}
          </p>
        </div>

        {/* Current status */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3.5 py-1.5 rounded-2xl">
          <span className="text-xs font-bold text-slate-500">Current Density:</span>
          <span className={`text-xs font-black px-2 py-0.5 rounded-full border ${getLevelBadge(bus.crowdLevel)}`}>
            {bus.crowdLevel} ({bus.crowdPercentage}%)
          </span>
        </div>
      </div>

      {/* Hourly Forecast Bar Chart */}
      <div className="space-y-3">
        <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">
          Predicted Timeline (Evening Commute)
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
          {predictions.map((slot, index) => (
            <div 
              key={index}
              className={`p-3 rounded-2xl border text-center transition flex flex-col justify-between ${
                slot.isRecommended 
                  ? 'bg-emerald-50/70 border-emerald-300 ring-2 ring-emerald-400/50 shadow-xs' 
                  : 'bg-slate-50/60 border-slate-200'
              }`}
            >
              <div>
                <span className="text-xs font-extrabold text-slate-800 flex items-center justify-center gap-1">
                  <Clock size={12} className="text-slate-400" />
                  {slot.time}
                </span>

                {slot.isRecommended && (
                  <span className="inline-block my-1 text-[10px] font-black text-emerald-800 bg-emerald-200/80 px-1.5 py-0.2 rounded-full uppercase">
                    ★ Best Time
                  </span>
                )}
              </div>

              {/* Mini visual bar */}
              <div className="my-2.5">
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getBarColor(slot.percentage)} rounded-full`}
                    style={{ width: `${slot.percentage}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded border ${getLevelBadge(slot.crowdLevel)}`}>
                  {slot.crowdLevel} ({slot.percentage}%)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Smart Travel Tip */}
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3">
        <div className="p-2 bg-emerald-600 text-white rounded-xl shrink-0">
          <Sparkles size={18} />
        </div>
        <div className="text-xs space-y-1">
          <p className="font-bold text-emerald-950">
            Smart Commute Recommendation
          </p>
          <p className="text-emerald-900 font-medium">
            Traveling at or after <span className="font-bold">07:30 PM</span> offers up to <span className="font-bold">65% less crowd</span> and guaranteed seated travel on this corridor.
          </p>
        </div>
      </div>
    </div>
  );
};
