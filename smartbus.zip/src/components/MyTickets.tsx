import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Booking } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import { 
  Ticket, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Armchair, 
  Share2, 
  Maximize2, 
  Bell, 
  ArrowRight,
  Download,
  AlertCircle
} from 'lucide-react';

interface MyTicketsProps {
  onBookNewTrip: () => void;
  onLiveTrackBus: (busId: string) => void;
}

export const MyTickets: React.FC<MyTicketsProps> = ({ onBookNewTrip, onLiveTrackBus }) => {
  const { bookings, setDestinationAlert, showToast, buses } = useApp();
  const [selectedTicketForQR, setSelectedTicketForQR] = useState<Booking | null>(null);

  const handleShare = (booking: Booking) => {
    navigator.clipboard.writeText(`${window.location.origin}/#ticket=${booking.bookingId}`);
    showToast('Ticket share link copied to clipboard! 📋', 'success');
  };

  const handleSetAlert = (booking: Booking) => {
    setDestinationAlert(booking.busNumber, booking.toLocation);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Ticket size={24} className="text-blue-600" />
            <span>My Digital Tickets ({bookings.length})</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Active QR passes, reservation history, and conductor validation receipts
          </p>
        </div>

        <button
          onClick={onBookNewTrip}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
        >
          <span>Book New Seat</span>
          <ArrowRight size={14} />
        </button>
      </div>

      {/* Bookings List */}
      {bookings.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-4 shadow-xs">
          <Ticket size={48} className="text-slate-300 mx-auto" />
          <h3 className="text-lg font-black text-slate-800">No Tickets Booked Yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Find your bus and book a seat with guaranteed anti-double-booking protection and instant QR generation.
          </p>
          <button
            onClick={onBookNewTrip}
            className="px-6 py-3 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-md"
          >
            Find a Bus Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5">
          {bookings.map((booking) => {
            const isBoarded = booking.bookingStatus === 'BOARDED';
            return (
              <div
                key={booking.id}
                className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-md transition"
              >
                <div className="p-6 sm:p-7 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  
                  {/* Left: Route & Meta */}
                  <div className="space-y-3 grow">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-blue-600 text-white font-black text-base flex items-center justify-center shadow-sm">
                        {booking.busNumber}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-black text-slate-900">
                            Bus {booking.busNumber}
                          </h3>
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                            isBoarded ? 'bg-purple-100 text-purple-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {isBoarded ? 'Boarded ✅' : 'Active Pass'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 font-semibold">{booking.fromLocation} → {booking.toLocation}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Seat</span>
                        <span className="font-black text-blue-600 text-sm">{booking.seatNumber}</span>
                      </div>

                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Booking ID</span>
                        <span className="font-mono font-bold text-slate-800 text-xs">{booking.bookingId}</span>
                      </div>

                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Fare</span>
                        <span className="font-black text-slate-900 text-sm">₹{booking.fare} (PAID)</span>
                      </div>

                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Passenger</span>
                        <span className="font-bold text-slate-800 text-xs truncate">{booking.passengerName}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Interactive QR preview & Quick Actions */}
                  <div className="flex flex-col items-center gap-3 shrink-0 w-full md:w-auto border-t md:border-t-0 pt-4 md:pt-0 border-slate-100">
                    <button
                      onClick={() => setSelectedTicketForQR(booking)}
                      className="p-3 bg-slate-50 hover:bg-slate-100 rounded-2xl border border-slate-200 transition group flex flex-col items-center"
                      title="Tap to view full QR code"
                    >
                      <QRCodeSVG
                        value={booking.qrPayload}
                        size={84}
                        level="M"
                      />
                      <span className="text-[10px] text-blue-600 font-bold mt-1.5 flex items-center gap-1">
                        <Maximize2 size={11} /> Tap for QR
                      </span>
                    </button>

                    <div className="flex gap-2 w-full">
                      <button
                        onClick={() => handleShare(booking)}
                        className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <Share2 size={12} /> Share
                      </button>

                      <button
                        onClick={() => handleSetAlert(booking)}
                        className="flex-1 px-3 py-1.5 rounded-lg border border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-900 text-[11px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <Bell size={12} /> Alert
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* QR Modal */}
      {selectedTicketForQR && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-7 max-w-sm w-full text-center space-y-4 shadow-2xl">
            <h3 className="text-lg font-black text-slate-900">
              Bus {selectedTicketForQR.busNumber} Digital Pass
            </h3>
            <p className="text-xs text-slate-500">
              Seat: <strong className="text-blue-600">{selectedTicketForQR.seatNumber}</strong> • Passenger: <strong>{selectedTicketForQR.passengerName}</strong>
            </p>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 inline-block">
              <QRCodeSVG
                value={selectedTicketForQR.qrPayload}
                size={220}
                level="H"
                includeMargin={true}
                className="mx-auto"
              />
            </div>

            <div className="font-mono text-sm font-bold text-slate-800">
              {selectedTicketForQR.bookingId}
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
              >
                <Download size={14} /> Print
              </button>

              <button
                onClick={() => setSelectedTicketForQR(null)}
                className="py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
