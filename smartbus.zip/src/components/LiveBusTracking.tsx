import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Bus, Stop } from '../types';
import { 
  Bus as BusIcon, 
  MapPin, 
  Clock, 
  Users, 
  Navigation, 
  Bell, 
  CheckCircle2, 
  ArrowRight, 
  RotateCcw, 
  Play, 
  Pause,
  ShieldCheck,
  Zap
} from 'lucide-react';

interface LiveBusTrackingProps {
  onSelectBusToBook: (bus: Bus) => void;
}

export const LiveBusTracking: React.FC<LiveBusTrackingProps> = ({ onSelectBusToBook }) => {
  const { buses, selectedBus, setSelectedBus, setDestinationAlert, t } = useApp();
  
  // Default to 21G if none selected
  const activeBus = selectedBus || buses[0];
  
  const [simulationActive, setSimulationActive] = useState(true);
  const [currentProgress, setCurrentProgress] = useState(35); // 0 to 100% along the route
  const [speedKmh, setSpeedKmh] = useState(38);
  const [selectedDestinationStop, setSelectedDestinationStop] = useState(activeBus.stops[activeBus.stops.length - 1]?.name || 'Guindy');
  const [destinationAlertConfirmed, setDestinationAlertConfirmed] = useState(false);

  // Simulated GPS movement
  useEffect(() => {
    if (!simulationActive) return;

    const timer = setInterval(() => {
      setCurrentProgress(prev => {
        if (prev >= 95) return 10;
        return prev + 1.5;
      });

      // Fluctuate speed realistically
      setSpeedKmh(Math.floor(32 + Math.random() * 14));
    }, 1200);

    return () => clearInterval(timer);
  }, [simulationActive]);

  const handleSetAlert = () => {
    setDestinationAlert(activeBus.busNumber, selectedDestinationStop);
    setDestinationAlertConfirmed(true);
    setTimeout(() => setDestinationAlertConfirmed(false), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Top Selector & Live Status Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-emerald-600">
              Live Fleet GPS Telemetry
            </span>
            <span className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-semibold">
              Live Demo Data
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
            Tracking Bus {activeBus.busNumber} – {activeBus.routeName}
          </h2>
        </div>

        {/* Bus switcher dropdown */}
        <div className="flex items-center gap-2 w-full md:w-auto">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">
            Switch Bus:
          </label>
          <select
            value={activeBus.id}
            onChange={(e) => {
              const b = buses.find(item => item.id === e.target.value);
              if (b) {
                setSelectedBus(b);
                setSelectedDestinationStop(b.stops[b.stops.length - 1]?.name || 'Destination');
              }
            }}
            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
          >
            {buses.map(b => (
              <option key={b.id} value={b.id}>
                {b.busNumber} ({b.fromLocation} → {b.toLocation})
              </option>
            ))}
          </select>

          <button
            onClick={() => setSimulationActive(!simulationActive)}
            className={`p-2 rounded-xl border text-xs font-bold transition flex items-center gap-1 ${
              simulationActive 
                ? 'bg-amber-50 text-amber-700 border-amber-200' 
                : 'bg-emerald-50 text-emerald-700 border-emerald-200'
            }`}
            title={simulationActive ? 'Pause GPS movement simulation' : 'Resume GPS movement simulation'}
          >
            {simulationActive ? <Pause size={15} /> : <Play size={15} />}
          </button>
        </div>
      </div>

      {/* Map Style Canvas Card */}
      <div className="relative bg-slate-900 rounded-3xl overflow-hidden shadow-xl border border-slate-800 text-white min-h-[380px] p-6 sm:p-8 flex flex-col justify-between">
        
        {/* Radar Map Grid Background styling */}
        <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px] opacity-40"></div>
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Map Top Floating Overlay */}
        <div className="relative z-10 flex flex-wrap justify-between items-start gap-4">
          <div className="bg-slate-800/90 backdrop-blur-md border border-slate-700/80 rounded-2xl p-3.5 shadow-lg max-w-sm">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black text-sm">
                {activeBus.busNumber}
              </div>
              <div>
                <p className="font-extrabold text-sm text-white">Live Speed: {speedKmh} km/h</p>
                <p className="text-[11px] text-slate-300 font-medium">GPS Signal: 🟢 Optimal (4G Telematics)</p>
              </div>
            </div>
            <div className="text-xs text-slate-300 space-y-0.5 border-t border-slate-700/60 pt-2 mt-2">
              <p>📍 Current: <span className="font-bold text-white">{activeBus.currentLocation}</span></p>
              <p>⏱ Next Stop: <span className="font-bold text-emerald-400">{activeBus.nextStop} ({activeBus.etaMinutes} min)</span></p>
              <p>🏁 Final Dest: <span className="font-bold text-white">{activeBus.toLocation}</span></p>
            </div>
          </div>

          {/* Crowd & Seats Floating badge */}
          <div className="bg-slate-800/90 backdrop-blur-md border border-slate-700/80 rounded-2xl p-3.5 shadow-lg text-right">
            <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Crowd Status</p>
            <p className={`text-sm font-black mt-0.5 ${
              activeBus.crowdLevel === 'High' ? 'text-red-400' : activeBus.crowdLevel === 'Medium' ? 'text-amber-400' : 'text-emerald-400'
            }`}>
              {activeBus.crowdLevel} ({activeBus.crowdPercentage}%)
            </p>
            <p className="text-xs text-emerald-300 font-semibold mt-1">
              💺 {activeBus.availableSeats} Seats Available
            </p>
          </div>
        </div>

        {/* Dynamic Route Waypoints & Bus Movement Visualization */}
        <div className="relative z-10 py-10 my-4">
          <div className="bg-slate-800/60 backdrop-blur-sm border border-slate-700/60 rounded-2xl p-5">
            <div className="flex justify-between items-center text-xs font-bold text-slate-400 mb-3">
              <span>{activeBus.fromLocation}</span>
              <span className="font-mono text-blue-400 font-bold">Simulated GPS Transit Track</span>
              <span>{activeBus.toLocation}</span>
            </div>

            {/* Simulated Road Line */}
            <div className="relative w-full h-3 bg-slate-950 rounded-full overflow-visible my-6">
              {/* Progress bar */}
              <div 
                className="h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-400 rounded-full transition-all duration-700"
                style={{ width: `${currentProgress}%` }}
              ></div>

              {/* Stops along the line */}
              {activeBus.stops.map((stop, index) => {
                const stepPos = (index / (activeBus.stops.length - 1)) * 100;
                const isPassed = currentProgress >= stepPos;
                return (
                  <div 
                    key={stop.id}
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center group cursor-pointer"
                    style={{ left: `${stepPos}%` }}
                    title={stop.name}
                  >
                    <div className={`w-4 h-4 rounded-full border-2 transition ${
                      isPassed ? 'bg-emerald-400 border-slate-900' : 'bg-slate-700 border-slate-900'
                    }`}></div>
                    <span className="text-[10px] text-slate-300 font-medium mt-2 whitespace-nowrap hidden sm:block">
                      {stop.name.split(' ')[0]}
                    </span>
                  </div>
                );
              })}

              {/* Moving Bus Marker */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 transition-all duration-700 z-20"
                style={{ left: `${currentProgress}%` }}
              >
                <div className="relative">
                  <div className="w-10 h-10 rounded-2xl bg-blue-500 text-white flex items-center justify-center shadow-lg shadow-blue-500/50 border-2 border-white animate-pulse">
                    <BusIcon size={20} />
                  </div>
                  <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded font-mono shadow-xs">
                    {activeBus.busNumber}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center text-[11px] text-slate-400 pt-2">
              <span className="text-emerald-400 font-bold">Departure: 06:15 PM</span>
              <span className="text-amber-300 font-bold">Approx. Speed: {speedKmh} km/h</span>
              <span className="text-blue-300 font-bold">ETA at Dest: {activeBus.etaMinutes + 12} min</span>
            </div>
          </div>
        </div>

        {/* Bottom Destination Alert Bar (Section 14: Destination Alert) */}
        <div className="relative z-10 bg-slate-800/90 backdrop-blur-md border border-slate-700 rounded-2xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0">
              <Bell size={18} />
            </div>
            <div>
              <p className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Set Proximity Destination Alert</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-medium">
                  2 Stops Away Notice
                </span>
              </p>
              <p className="text-[11px] text-slate-300">
                Receive proactive audio & visual alert when your stop is approaching.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={selectedDestinationStop}
              onChange={(e) => setSelectedDestinationStop(e.target.value)}
              className="px-3 py-2 bg-slate-900 text-white border border-slate-700 rounded-xl text-xs font-semibold focus:outline-none"
            >
              {activeBus.stops.map(s => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>

            <button
              id="set-dest-alert-btn"
              onClick={handleSetAlert}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl transition cursor-pointer shrink-0"
            >
              {destinationAlertConfirmed ? 'Alert Set! ✅' : 'Set Alert'}
            </button>
          </div>
        </div>

      </div>

      {/* Book this Bus CTA Bar */}
      <div className="bg-blue-50 border border-blue-200 rounded-3xl p-5 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <h3 className="text-base font-black text-slate-900">
            Want to travel on Bus {activeBus.busNumber}?
          </h3>
          <p className="text-xs text-slate-600">
            {activeBus.availableSeats} seats remaining • Standard Fixed Fare: ₹{activeBus.fare}
          </p>
        </div>

        <button
          onClick={() => onSelectBusToBook(activeBus)}
          className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>{t.bookSeat} on {activeBus.busNumber}</span>
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
};
