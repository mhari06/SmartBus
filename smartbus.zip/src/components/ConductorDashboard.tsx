import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Booking } from '../types';
import { 
  Scan, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  Armchair, 
  Users, 
  Ticket, 
  ShieldCheck, 
  Camera, 
  RotateCcw,
  Sparkles,
  Clock
} from 'lucide-react';

export const ConductorDashboard: React.FC<ConductorDashboardProps> = () => {
  const { 
    bookings, 
    buses, 
    verifyBookingById, 
    confirmBoarding, 
    showToast 
  } = useApp();

  const [selectedBusId, setSelectedBusId] = useState<string>(buses[0]?.id || 'bus-21g');
  const [searchInput, setSearchInput] = useState('');
  const [verifiedBooking, setVerifiedBooking] = useState<Booking | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [isScanningSimulation, setIsScanningSimulation] = useState(false);

  const currentBus = buses.find(b => b.id === selectedBusId) || buses[0];
  const busBookings = bookings.filter(b => b.busId === currentBus.id || b.busNumber === currentBus.busNumber);

  const totalBookedCount = busBookings.length;
  const boardedCount = busBookings.filter(b => b.bookingStatus === 'BOARDED').length;
  const remainingSeatsCount = currentBus.availableSeats;
  const paidCount = busBookings.filter(b => b.paymentStatus === 'PAID').length;

  const handleVerify = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSearchError(null);

    if (!searchInput.trim()) {
      setSearchError('Please enter a valid Booking ID (e.g., SB-2030-1001)');
      return;
    }

    const found = verifyBookingById(searchInput.trim());
    if (found) {
      setVerifiedBooking(found);
      showToast(`Valid Ticket Found: ${found.bookingId}`, 'success');
    } else {
      setVerifiedBooking(null);
      setSearchError(`No booking found with ID "${searchInput}". Please check with passenger.`);
    }
  };

  const handleSimulateQRScan = () => {
    setIsScanningSimulation(true);
    setSearchError(null);

    // Pick first active booking or generate sample
    setTimeout(() => {
      setIsScanningSimulation(false);
      const target = busBookings[0] || bookings[0];
      if (target) {
        setSearchInput(target.bookingId);
        setVerifiedBooking(target);
        showToast(`QR Code Scanned: ${target.bookingId}`, 'success');
      } else {
        setSearchError('No active QR code detected in scanner frame.');
      }
    }, 1200);
  };

  const handleConfirmBoarding = (bookingId: string) => {
    const success = confirmBoarding(bookingId);
    if (success) {
      const refreshed = verifyBookingById(bookingId);
      setVerifiedBooking(refreshed);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-slate-900 text-white p-6 sm:p-7 rounded-3xl shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-emerald-400">
              Conductor Mobile Validation Terminal
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
            Bus {currentBus.busNumber} • Duty Console
          </h2>
          <p className="text-xs text-slate-300 font-medium">{currentBus.routeName}</p>
        </div>

        {/* Bus Duty Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-bold uppercase">Active Bus:</span>
          <select
            value={selectedBusId}
            onChange={(e) => {
              setSelectedBusId(e.target.value);
              setVerifiedBooking(null);
            }}
            className="px-3 py-2 bg-slate-800 text-white border border-slate-700 rounded-xl text-xs font-bold focus:outline-none"
          >
            {buses.map(b => (
              <option key={b.id} value={b.id}>
                Bus {b.busNumber} ({b.fromLocation} → {b.toLocation})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 4 Stats Cards (Section 8) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-center text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Bookings</span>
            <Ticket size={18} className="text-blue-600" />
          </div>
          <p className="text-2xl font-black text-slate-900">{totalBookedCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">Seats reserved online</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-center text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Paid Tickets</span>
            <ShieldCheck size={18} className="text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-600">{paidCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">100% verified fares</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-center text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Boarded</span>
            <Users size={18} className="text-purple-600" />
          </div>
          <p className="text-2xl font-black text-purple-600">{boardedCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">Passengers on coach</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex justify-between items-center text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Seats Free</span>
            <Armchair size={18} className="text-amber-500" />
          </div>
          <p className="text-2xl font-black text-slate-900">{remainingSeatsCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">Available for walk-ins</p>
        </div>
      </div>

      {/* Main Validation Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left: Search / Scan Console */}
        <div className="lg:col-span-6 bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-5">
          <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Scan size={20} className="text-blue-600" />
            <span>Passenger QR & Ticket Verification</span>
          </h3>

          {/* Quick Scanner Action */}
          <button
            id="conductor-scan-qr-btn"
            type="button"
            onClick={handleSimulateQRScan}
            disabled={isScanningSimulation}
            className="w-full py-4 bg-blue-50 hover:bg-blue-100 text-blue-700 border-2 border-dashed border-blue-300 rounded-2xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer"
          >
            {isScanningSimulation ? (
              <>
                <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <span>Scanning Camera QR Frame...</span>
              </>
            ) : (
              <>
                <Camera size={18} className="text-blue-600" />
                <span>Simulate Camera QR Scanner Tap</span>
              </>
            )}
          </button>

          <div className="relative flex py-1 items-center">
            <div className="grow border-t border-slate-200"></div>
            <span className="shrink mx-4 text-slate-400 text-xs font-bold uppercase">Or Enter Booking ID</span>
            <div className="grow border-t border-slate-200"></div>
          </div>

          {/* Search Form */}
          <form onSubmit={handleVerify} className="space-y-3">
            <div className="flex gap-2">
              <input
                id="conductor-booking-id-input"
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Enter Booking ID (e.g. SB-2030-1001)"
                className="grow px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <button
                type="submit"
                className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Verify
              </button>
            </div>
          </form>

          {searchError && (
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-2xl flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0 text-red-600" />
              <span>{searchError}</span>
            </div>
          )}

          {/* Quick Bookings on this bus */}
          <div className="space-y-2 pt-2">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Quick Select Today's Passenger Bookings:
            </p>
            <div className="flex flex-wrap gap-2">
              {busBookings.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    setSearchInput(b.bookingId);
                    setVerifiedBooking(b);
                  }}
                  className={`text-xs font-mono font-bold px-3 py-1.5 rounded-xl border transition ${
                    verifiedBooking?.id === b.id
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {b.bookingId} ({b.seatNumber}) {b.bookingStatus === 'BOARDED' ? '✓' : ''}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Validation Result Card */}
        <div className="lg:col-span-6 space-y-4">
          {verifiedBooking ? (
            <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-sm space-y-5">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-mono text-emerald-600 font-bold uppercase tracking-wider">
                    VALID PASSENGER TICKET
                  </span>
                  <h3 className="text-xl font-black text-slate-900 mt-0.5">
                    {verifiedBooking.passengerName}
                  </h3>
                  <p className="text-xs text-slate-500 font-semibold">{verifiedBooking.passengerPhone}</p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Status</span>
                  <span className={`text-xs font-black px-2.5 py-1 rounded-full inline-block mt-0.5 ${
                    verifiedBooking.bookingStatus === 'BOARDED'
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {verifiedBooking.bookingStatus === 'BOARDED' ? 'Boarded ✅' : 'Valid Ticket'}
                  </span>
                </div>
              </div>

              {/* Data Table */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <div>
                  <span className="text-slate-400 font-bold block">Assigned Seat</span>
                  <span className="text-base font-black text-blue-600">{verifiedBooking.seatNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block">Fare Paid</span>
                  <span className="text-base font-black text-slate-900">₹{verifiedBooking.fare} (PAID)</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block">Route</span>
                  <span className="font-bold text-slate-800">{verifiedBooking.fromLocation} → {verifiedBooking.toLocation}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-bold block">Booking Code</span>
                  <span className="font-mono font-bold text-slate-800">{verifiedBooking.bookingId}</span>
                </div>
              </div>

              {verifiedBooking.boardingVerifiedAt && (
                <div className="flex items-center gap-2 text-xs text-purple-700 bg-purple-50 p-3 rounded-xl">
                  <Clock size={14} />
                  <span>Boarding verified at {verifiedBooking.boardingVerifiedAt}</span>
                </div>
              )}

              {/* Confirm Boarding Button */}
              {verifiedBooking.bookingStatus !== 'BOARDED' ? (
                <button
                  id="confirm-boarding-action-btn"
                  onClick={() => handleConfirmBoarding(verifiedBooking.bookingId)}
                  className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-sm rounded-2xl shadow-lg shadow-emerald-600/25 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 size={18} />
                  <span>Confirm Passenger Boarding</span>
                </button>
              ) : (
                <div className="w-full py-3.5 bg-slate-100 text-slate-500 font-bold text-xs rounded-2xl text-center flex items-center justify-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600" />
                  <span>Boarding Already Confirmed for this Trip</span>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center space-y-3">
              <Scan size={36} className="text-slate-300 mx-auto" />
              <h4 className="text-sm font-bold text-slate-700">No Ticket Selected for Validation</h4>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Scan the passenger's digital QR ticket or enter their Booking ID on the left to verify seating and confirm boarding.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

interface ConductorDashboardProps {}
