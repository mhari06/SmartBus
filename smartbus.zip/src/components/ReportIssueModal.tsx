import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SafetyReport } from '../types';
import { 
  AlertTriangle, 
  X, 
  CheckCircle2, 
  HelpCircle, 
  PackageSearch, 
  Send 
} from 'lucide-react';

interface ReportIssueModalProps {
  onClose: () => void;
  onOpenLostFound: () => void;
}

export const ReportIssueModal: React.FC<ReportIssueModalProps> = ({ onClose, onOpenLostFound }) => {
  const { buses, submitReport, userProfile } = useApp();

  const [busNumber, setBusNumber] = useState(buses[0]?.busNumber || '21G');
  const [reportType, setReportType] = useState<SafetyReport['reportType']>('Overcrowding');
  const [description, setDescription] = useState('');
  const [contactMethod, setContactMethod] = useState(userProfile.phone);
  const [submitted, setSubmitted] = useState(false);

  const categories: SafetyReport['reportType'][] = [
    'Bus Delay',
    'Overcrowding',
    'Unsafe Situation',
    'Seat Issue',
    'Route Issue',
    'Lost Item',
    'Other'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    submitReport(busNumber, reportType, description, contactMethod);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 text-left">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 relative flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
              <AlertTriangle size={15} />
              <span>Transit Support & Incident Desk</span>
            </div>
            <h2 className="text-xl font-black text-white">
              Report a Problem
            </h2>
            <p className="text-xs text-slate-300">
              Direct report dispatched to Depot Operations & Traffic Control
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X size={16} />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 size={32} />
            </div>
            <h3 className="text-xl font-black text-slate-900">Report Submitted</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Thank you for helping keep SmartBus safe and efficient. Ticket #TR-{Date.now().toString().slice(-6)} has been logged with depot supervisors.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3.5 bg-slate-900 text-white font-bold text-xs rounded-xl shadow-md"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            
            {/* Quick Switch to Lost & Found if applicable */}
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl flex justify-between items-center text-xs">
              <div className="flex items-center gap-2 text-blue-900 font-semibold">
                <PackageSearch size={16} className="text-blue-600" />
                <span>Lost your wallet, bag, or keys on the bus?</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenLostFound();
                }}
                className="text-xs font-bold text-blue-700 bg-white px-2.5 py-1 rounded-lg border border-blue-200 hover:bg-blue-100 transition"
              >
                Lost & Found →
              </button>
            </div>

            {/* Bus Select */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Affected Bus Number
              </label>
              <select
                value={busNumber}
                onChange={(e) => setBusNumber(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {buses.map(b => (
                  <option key={b.id} value={b.busNumber}>
                    Bus {b.busNumber} ({b.fromLocation} → {b.toLocation})
                  </option>
                ))}
              </select>
            </div>

            {/* Category Select */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Issue Category
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setReportType(cat)}
                    className={`p-2.5 rounded-xl border text-xs font-bold text-left transition ${
                      reportType === cat
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Incident Details & Location
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe what happened, the stop location, or any specific details..."
                rows={3}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                required
              />
            </div>

            {/* Contact */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Contact Phone (For Follow-Up)
              </label>
              <input
                type="text"
                value={contactMethod}
                onChange={(e) => setContactMethod(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <Send size={13} />
                <span>Submit Report</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
