import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Search, Ticket, Shield, User, HeartHandshake } from 'lucide-react';

interface BottomNavProps {
  onOpenProfile: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ onOpenProfile }) => {
  const { activeView, setActiveView, bookings, userProfile } = useApp();
  const activeTicketsCount = bookings.filter(b => b.bookingStatus === 'BOOKED').length;

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1 flex justify-around items-center shadow-lg">
      <button
        onClick={() => setActiveView('home')}
        className={`flex flex-col items-center py-1 px-3 rounded-lg text-[11px] font-semibold transition ${
          activeView === 'home' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Home size={20} />
        <span>Home</span>
      </button>

      <button
        onClick={() => setActiveView('search')}
        className={`flex flex-col items-center py-1 px-3 rounded-lg text-[11px] font-semibold transition ${
          activeView === 'search' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Search size={20} />
        <span>Search</span>
      </button>

      <button
        onClick={() => setActiveView('tickets')}
        className={`relative flex flex-col items-center py-1 px-3 rounded-lg text-[11px] font-semibold transition ${
          activeView === 'tickets' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Ticket size={20} />
        <span>Tickets</span>
        {activeTicketsCount > 0 && (
          <span className="absolute top-0.5 right-2 bg-blue-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
            {activeTicketsCount}
          </span>
        )}
      </button>

      <button
        onClick={() => setActiveView(userProfile.womenSafetyMode ? 'women-safety' : 'safety')}
        className={`flex flex-col items-center py-1 px-3 rounded-lg text-[11px] font-semibold transition ${
          activeView === 'safety' || activeView === 'women-safety'
            ? 'text-emerald-600 font-bold'
            : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        {userProfile.womenSafetyMode ? <HeartHandshake size={20} className="text-pink-600" /> : <Shield size={20} className="text-emerald-600" />}
        <span>{userProfile.womenSafetyMode ? 'Women' : 'Safety'}</span>
      </button>

      <button
        onClick={onOpenProfile}
        className="flex flex-col items-center py-1 px-3 rounded-lg text-[11px] font-semibold text-slate-500 hover:text-slate-800"
      >
        <User size={20} />
        <span>Profile</span>
      </button>
    </nav>
  );
};
