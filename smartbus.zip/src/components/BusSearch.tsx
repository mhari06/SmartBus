import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LOCATIONS } from '../data/mockData';
import { 
  Search, 
  MapPin, 
  Calendar, 
  Clock, 
  ArrowUpDown, 
  Sparkles,
  Zap
} from 'lucide-react';

export const BusSearch: React.FC = () => {
  const { searchParams, setSearchParams, performSearch, t } = useApp();

  const [from, setFrom] = useState(searchParams.from);
  const [to, setTo] = useState(searchParams.to);
  const [date, setDate] = useState(searchParams.date);
  const [time, setTime] = useState(searchParams.time);

  const handleSwap = () => {
    const temp = from;
    setFrom(to);
    setTo(temp);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(from, to, date, time);
  };

  const quickRoutes = [
    { from: 'Tambaram', to: 'Guindy' },
    { from: 'Tambaram', to: 'Chennai Central' },
    { from: 'Chromepet', to: 'T Nagar' },
    { from: 'Pallavaram', to: 'Egmore' }
  ];

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200/80 mb-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>{t.searchBuses}</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Search live scheduled and active buses across Chennai metropolitan network
          </p>
        </div>

        {/* Quick popular chips */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-xs font-semibold text-slate-400">Popular:</span>
          {quickRoutes.map((qr, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setFrom(qr.from);
                setTo(qr.to);
                performSearch(qr.from, qr.to, date, time);
              }}
              className="text-[11px] font-bold bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-700 px-2.5 py-1 rounded-lg transition"
            >
              {qr.from} → {qr.to}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSearchSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-4 items-center">
          
          {/* From Field */}
          <div className="md:col-span-4 relative">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {t.from}
            </label>
            <div className="relative flex items-center">
              <div className="absolute left-3.5 text-blue-600 pointer-events-none">
                <MapPin size={18} />
              </div>
              <select
                id="search-from-select"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 border border-slate-200 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition appearance-none"
              >
                {LOCATIONS.map((loc) => (
                  <option key={`from-${loc}`} value={loc} disabled={loc === to}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Swap Button */}
          <div className="md:col-span-1 flex justify-center md:pt-6">
            <button
              type="button"
              onClick={handleSwap}
              className="w-10 h-10 rounded-full border border-slate-200 bg-slate-50 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 text-slate-600 flex items-center justify-center transition shadow-xs"
              title="Swap origin and destination"
            >
              <ArrowUpDown size={16} />
            </button>
          </div>

          {/* To Field */}
          <div className="md:col-span-4 relative">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              {t.to}
            </label>
            <div className="relative flex items-center">
              <div className="absolute left-3.5 text-red-500 pointer-events-none">
                <MapPin size={18} />
              </div>
              <select
                id="search-to-select"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 border border-slate-200 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition appearance-none"
              >
                {LOCATIONS.map((loc) => (
                  <option key={`to-${loc}`} value={loc} disabled={loc === from}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date & Time combined */}
          <div className="md:col-span-3 grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                {t.date}
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-3 bg-slate-50 text-slate-900 border border-slate-200 rounded-2xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                {t.time}
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-3 bg-slate-50 text-slate-900 border border-slate-200 rounded-2xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition"
              />
            </div>
          </div>

        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-2">
          <button
            id="search-buses-submit-btn"
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-sm sm:text-base rounded-2xl shadow-lg shadow-blue-600/25 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Search size={18} />
            <span>{t.searchBuses}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
