import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bus, CrowdLevel } from '../types';
import { 
  Sliders, 
  Plus, 
  Edit3, 
  Trash2, 
  Bus as BusIcon, 
  ShieldAlert, 
  Ticket, 
  Users, 
  Armchair, 
  CheckCircle2, 
  X,
  PackageSearch,
  Zap
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { 
    buses, 
    addBus, 
    updateBus, 
    deleteBus, 
    bookings, 
    reports, 
    lostItems, 
    safetyAlerts,
    showToast 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'buses' | 'reports' | 'lost'>('buses');
  const [addBusModalOpen, setAddBusModalOpen] = useState(false);
  const [editingBus, setEditingBus] = useState<Bus | null>(null);

  // New Bus form state
  const [newBusNumber, setNewBusNumber] = useState('');
  const [newRouteName, setNewRouteName] = useState('');
  const [newFrom, setNewFrom] = useState('Tambaram');
  const [newTo, setNewTo] = useState('Guindy');
  const [newFare, setNewFare] = useState<number>(20);
  const [newTotalSeats, setNewTotalSeats] = useState<number>(28);
  const [newCrowdLevel, setNewCrowdLevel] = useState<CrowdLevel>('Medium');
  const [newAcType, setNewAcType] = useState<'AC' | 'Non-AC'>('Non-AC');

  const totalSeatsInFleet = buses.reduce((sum, b) => sum + b.totalSeats, 0);
  const totalAvailableSeats = buses.reduce((sum, b) => sum + b.availableSeats, 0);

  const handleCreateBus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBusNumber.trim() || !newRouteName.trim()) return;

    addBus({
      busNumber: newBusNumber.toUpperCase(),
      routeId: `route-${newBusNumber.toLowerCase()}`,
      routeName: newRouteName,
      fromLocation: newFrom,
      toLocation: newTo,
      currentLocation: newFrom,
      nextStop: 'First Junction',
      etaMinutes: 10,
      crowdLevel: newCrowdLevel,
      crowdPercentage: newCrowdLevel === 'High' ? 85 : newCrowdLevel === 'Medium' ? 55 : 25,
      totalSeats: newTotalSeats,
      availableSeats: newTotalSeats,
      fare: Number(newFare),
      status: 'On Time',
      acType: newAcType,
      isElectric: true,
      batteryPercentage: 90,
      wheelchairAccessible: true,
      safetyRating: 5.0
    });

    setAddBusModalOpen(false);
    setNewBusNumber('');
    setNewRouteName('');
  };

  const handleUpdateBusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBus) return;

    updateBus(editingBus.id, editingBus);
    setEditingBus(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-indigo-900 text-white p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse"></span>
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-indigo-300">
              System Admin & Dispatch Operations
            </span>
          </div>
          <h2 className="text-2xl font-black text-white mt-1">
            Transit Fleet Control Panel
          </h2>
          <p className="text-xs text-indigo-200">
            Real-time schedule management, dynamic fare setting, route updates, and incident triage
          </p>
        </div>

        <button
          onClick={() => setAddBusModalOpen(true)}
          className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer"
        >
          <Plus size={16} />
          <span>Add New Bus to Fleet</span>
        </button>
      </div>

      {/* 5 Stats Cards (Section 19) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Total Buses</p>
          <p className="text-2xl font-black text-slate-900 mt-0.5">{buses.length}</p>
          <p className="text-[11px] text-emerald-600 font-semibold">Active in Fleet</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Total Bookings</p>
          <p className="text-2xl font-black text-blue-600 mt-0.5">{bookings.length}</p>
          <p className="text-[11px] text-slate-400 font-semibold">Confirmed Tickets</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Network Seats</p>
          <p className="text-2xl font-black text-slate-900 mt-0.5">{totalAvailableSeats} / {totalSeatsInFleet}</p>
          <p className="text-[11px] text-emerald-600 font-semibold">Available for Sale</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Safety Incidents</p>
          <p className="text-2xl font-black text-red-600 mt-0.5">{reports.length + safetyAlerts.length}</p>
          <p className="text-[11px] text-red-500 font-semibold">Logged Reports</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs col-span-2 lg:col-span-1">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Lost Property</p>
          <p className="text-2xl font-black text-amber-600 mt-0.5">{lostItems.length}</p>
          <p className="text-[11px] text-slate-400 font-semibold">Items Reported</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('buses')}
          className={`pb-3 transition border-b-2 ${
            activeTab === 'buses'
              ? 'border-indigo-600 text-indigo-600 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Fleet Management ({buses.length})
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`pb-3 transition border-b-2 flex items-center gap-1.5 ${
            activeTab === 'reports'
              ? 'border-indigo-600 text-indigo-600 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>Safety Reports</span>
          {reports.length > 0 && (
            <span className="bg-red-600 text-white text-[10px] px-1.5 rounded-full">
              {reports.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('lost')}
          className={`pb-3 transition border-b-2 ${
            activeTab === 'lost'
              ? 'border-indigo-600 text-indigo-600 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Lost & Found Desk ({lostItems.length})
        </button>
      </div>

      {/* Tab 1: Fleet Management Table */}
      {activeTab === 'buses' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Bus #</th>
                  <th className="py-3.5 px-4">Route Name</th>
                  <th className="py-3.5 px-4">Corridor</th>
                  <th className="py-3.5 px-4">Fare</th>
                  <th className="py-3.5 px-4">Seats</th>
                  <th className="py-3.5 px-4">Crowd</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {buses.map((bus) => (
                  <tr key={bus.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4 font-black text-slate-900">
                      <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-mono">
                        {bus.busNumber}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">{bus.routeName}</td>
                    <td className="py-3.5 px-4 text-slate-600">{bus.fromLocation} → {bus.toLocation}</td>
                    <td className="py-3.5 px-4 font-black text-slate-900">₹{bus.fare}</td>
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-emerald-600">{bus.availableSeats}</span>
                      <span className="text-slate-400">/{bus.totalSeats}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        bus.crowdLevel === 'High' ? 'bg-red-100 text-red-700' : bus.crowdLevel === 'Medium' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {bus.crowdLevel} ({bus.crowdPercentage}%)
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        bus.status === 'On Time' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {bus.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingBus(bus)}
                          className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 transition"
                          title="Edit bus details"
                        >
                          <Edit3 size={14} />
                        </button>
                        <button
                          onClick={() => deleteBus(bus.id)}
                          className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                          title="Delete from fleet"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Safety Reports */}
      {activeTab === 'reports' && (
        <div className="space-y-3">
          {reports.length === 0 ? (
            <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center text-xs text-slate-400">
              No passenger problem reports logged.
            </div>
          ) : (
            reports.map((r) => (
              <div key={r.id} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex justify-between items-start text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
                      {r.reportType}
                    </span>
                    <span className="font-bold text-slate-800">Bus {r.busNumber}</span>
                    <span className="text-slate-400">• {r.timestamp}</span>
                  </div>
                  <p className="text-slate-700 font-medium text-xs mt-1">{r.description}</p>
                  <p className="text-[11px] text-slate-400">Contact: {r.contactMethod}</p>
                </div>

                <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                  {r.status}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 3: Lost & Found */}
      {activeTab === 'lost' && (
        <div className="space-y-3">
          {lostItems.length === 0 ? (
            <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center text-xs text-slate-400">
              No lost items reported currently.
            </div>
          ) : (
            lostItems.map((item) => (
              <div key={item.id} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex justify-between items-start text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-slate-900 text-sm">{item.item}</span>
                    <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-bold">Bus {item.busNumber} (Seat {item.seatNumber})</span>
                  </div>
                  <p className="text-slate-600 font-medium">{item.description}</p>
                  <p className="text-[11px] text-slate-400">Reported: {item.reportedAt} • Contact: {item.contactMethod}</p>
                </div>

                <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
                  {item.status}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Modal: Add Bus */}
      {addBusModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-4 text-left">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="text-lg font-black text-slate-900">Add New Bus to Transit Fleet</h3>
              <button onClick={() => setAddBusModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateBus} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Bus Number (e.g. 570)</label>
                  <input
                    type="text"
                    value={newBusNumber}
                    onChange={(e) => setNewBusNumber(e.target.value)}
                    placeholder="570"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold uppercase"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Fare (₹)</label>
                  <input
                    type="number"
                    value={newFare}
                    onChange={(e) => setNewFare(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Route Name</label>
                <input
                  type="text"
                  value={newRouteName}
                  onChange={(e) => setNewRouteName(e.target.value)}
                  placeholder="Kelambakkam ⇄ CMBT / Koyambedu"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Origin Terminal</label>
                  <input
                    type="text"
                    value={newFrom}
                    onChange={(e) => setNewFrom(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Destination Terminal</label>
                  <input
                    type="text"
                    value={newTo}
                    onChange={(e) => setNewTo(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Initial Crowd Level</label>
                  <select
                    value={newCrowdLevel}
                    onChange={(e) => setNewCrowdLevel(e.target.value as CrowdLevel)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Coach Type</label>
                  <select
                    value={newAcType}
                    onChange={(e) => setNewAcType(e.target.value as 'AC' | 'Non-AC')}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="AC">AC Express</option>
                    <option value="Non-AC">Non-AC Standard</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setAddBusModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-md"
                >
                  Deploy Bus
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Bus */}
      {editingBus && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-left">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="text-lg font-black text-slate-900">Edit Bus {editingBus.busNumber}</h3>
              <button onClick={() => setEditingBus(null)} className="text-slate-400">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleUpdateBusSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Route Name</label>
                <input
                  type="text"
                  value={editingBus.routeName}
                  onChange={(e) => setEditingBus({ ...editingBus, routeName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Fare (₹)</label>
                  <input
                    type="number"
                    value={editingBus.fare}
                    onChange={(e) => setEditingBus({ ...editingBus, fare: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Status</label>
                  <select
                    value={editingBus.status}
                    onChange={(e) => setEditingBus({ ...editingBus, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="On Time">On Time</option>
                    <option value="Delayed">Delayed</option>
                    <option value="Departing Soon">Departing Soon</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingBus(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 text-white rounded-xl font-bold shadow-md"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
