import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bus, Seat } from '../types';
import { 
  Armchair, 
  ShieldCheck, 
  ArrowLeft, 
  ArrowRight, 
  AlertCircle, 
  Sparkles, 
  CheckCircle2,
  HeartHandshake
} from 'lucide-react';

interface SeatBookingProps {
  bus: Bus;
  onBack: () => void;
  onProceedToConfirm: (seatNumber: string) => void;
}

export const SeatBooking: React.FC<SeatBookingProps> = ({ bus, onBack, onProceedToConfirm }) => {
  const { getSeatsForBus, userProfile, t } = useApp();
  const seats = getSeatsForBus(bus.id);

  const [selectedSeatNumber, setSelectedSeatNumber] = useState<string | null>(null);
  const [doubleBookingError, setDoubleBookingError] = useState<string | null>(null);

  const handleSeatClick = (seat: Seat) => {
    setDoubleBookingError(null);

    if (seat.status === 'BOOKED') {
      setDoubleBookingError('This seat is already booked by another passenger.');
      return;
    }

    if (selectedSeatNumber === seat.seatNumber) {
      setSelectedSeatNumber(null); // Deselect
    } else {
      setSelectedSeatNumber(seat.seatNumber);
    }
  };

  const handleProceed = () => {
    if (!selectedSeatNumber) {
      setDoubleBookingError('Please select one available seat to proceed.');
      return;
    }

    // Re-verify double-booking lock
    const currentLatest = getSeatsForBus(bus.id).find(s => s.seatNumber === selectedSeatNumber);
    if (currentLatest && currentLatest.status === 'BOOKED') {
      setDoubleBookingError('This seat was just booked by another passenger. Please choose another seat.');
      setSelectedSeatNumber(null);
      return;
    }

    onProceedToConfirm(selectedSeatNumber);
  };

  // Group seats by row (A, B, C, D, E, F, G)
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-slate-900">Select Your Seat</span>
              <span className="bg-blue-100 text-blue-800 text-xs font-black px-2.5 py-0.5 rounded-full">
                Bus {bus.busNumber}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">{bus.fromLocation} → {bus.toLocation}</p>
          </div>
        </div>

        {/* Selected Seat & Fare Badge */}
        <div className="flex items-center gap-3 bg-slate-50 p-2.5 px-4 rounded-2xl border border-slate-200">
          <div>
            <p className="text-[10px] text-slate-400 uppercase font-bold">Selected</p>
            <p className="text-base font-black text-blue-600">
              {selectedSeatNumber ? `Seat ${selectedSeatNumber}` : 'None (Select 1)'}
            </p>
          </div>
          <div className="h-7 w-px bg-slate-200"></div>
          <div>
            <p className="text-[10px] text-slate-400 uppercase font-bold">Total Fare</p>
            <p className="text-base font-black text-slate-900">₹{bus.fare}</p>
          </div>
        </div>
      </div>

      {/* Error / Alert banner */}
      {doubleBookingError && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-2xl flex items-center gap-3 text-xs sm:text-sm font-semibold animate-shake">
          <AlertCircle size={20} className="shrink-0 text-red-600" />
          <span>{doubleBookingError}</span>
        </div>
      )}

      {/* Main Bus Coach Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        
        {/* Left / Center: Interactive Coach */}
        <div className="md:col-span-8 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm text-center">
          
          {/* Coach Front Header (Windshield & Driver) */}
          <div className="max-w-md mx-auto mb-8">
            <div className="h-6 bg-slate-800 rounded-t-3xl flex items-center justify-center text-[10px] font-mono tracking-widest text-slate-400 font-bold uppercase">
              Front Windshield
            </div>
            
            <div className="bg-slate-100 p-3 flex justify-between items-center border-x border-slate-300">
              <div className="flex items-center gap-2 bg-slate-200/80 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700">
                <span>🚪 Passenger Entry Door</span>
              </div>

              <div className="flex items-center gap-1.5 bg-slate-900 text-white px-3 py-1.5 rounded-xl text-xs font-bold shadow-xs">
                <span>👨‍✈️ Driver</span>
              </div>
            </div>

            {/* Coach Interior Layout */}
            <div className="bg-slate-50 border border-slate-200 p-6 rounded-b-3xl space-y-4">
              
              {/* Row mapping */}
              {rows.map((rowLetter) => {
                const rowSeats = seats.filter(s => s.row === rowLetter);
                const leftPair = rowSeats.filter(s => s.col === 1 || s.col === 2);
                const rightPair = rowSeats.filter(s => s.col === 3 || s.col === 4);
                const isWomenRow = rowLetter === 'A' || rowLetter === 'B';

                return (
                  <div key={rowLetter} className="flex justify-between items-center gap-2">
                    
                    {/* Left 2 Seats (Aisle & Window) */}
                    <div className="flex gap-2">
                      {leftPair.map((seat) => {
                        const isSelected = selectedSeatNumber === seat.seatNumber;
                        const isBooked = seat.status === 'BOOKED';
                        
                        return (
                          <button
                            key={seat.id}
                            type="button"
                            onClick={() => handleSeatClick(seat)}
                            disabled={isBooked}
                            id={`seat-btn-${seat.seatNumber}`}
                            className={`w-11 h-12 rounded-xl flex flex-col items-center justify-center text-xs font-bold transition transform cursor-pointer ${
                              isBooked
                                ? 'bg-red-100 text-red-400 border border-red-200 cursor-not-allowed opacity-75'
                                : isSelected
                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/40 ring-2 ring-blue-600 scale-105'
                                : isWomenRow
                                ? 'bg-pink-100/80 text-pink-900 border border-pink-300 hover:bg-pink-200'
                                : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300'
                            }`}
                            title={`Seat ${seat.seatNumber} (${isBooked ? 'Booked' : isWomenRow ? 'Women Priority' : 'Available'})`}
                          >
                            <Armchair size={16} />
                            <span className="text-[10px] mt-0.5 leading-none">{seat.seatNumber}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Middle Walking Aisle */}
                    <div className="text-[10px] font-mono font-bold text-slate-300 px-2 select-none">
                      AISLE
                    </div>

                    {/* Right 2 Seats (Aisle & Window) */}
                    <div className="flex gap-2">
                      {rightPair.map((seat) => {
                        const isSelected = selectedSeatNumber === seat.seatNumber;
                        const isBooked = seat.status === 'BOOKED';

                        return (
                          <button
                            key={seat.id}
                            type="button"
                            onClick={() => handleSeatClick(seat)}
                            disabled={isBooked}
                            id={`seat-btn-${seat.seatNumber}`}
                            className={`w-11 h-12 rounded-xl flex flex-col items-center justify-center text-xs font-bold transition transform cursor-pointer ${
                              isBooked
                                ? 'bg-red-100 text-red-400 border border-red-200 cursor-not-allowed opacity-75'
                                : isSelected
                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/40 ring-2 ring-blue-600 scale-105'
                                : isWomenRow
                                ? 'bg-pink-100/80 text-pink-900 border border-pink-300 hover:bg-pink-200'
                                : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300'
                            }`}
                            title={`Seat ${seat.seatNumber} (${isBooked ? 'Booked' : isWomenRow ? 'Women Priority' : 'Available'})`}
                          >
                            <Armchair size={16} />
                            <span className="text-[10px] mt-0.5 leading-none">{seat.seatNumber}</span>
                          </button>
                        );
                      })}
                    </div>

                  </div>
                );
              })}

            </div>
          </div>

          {/* Color Legend Bar */}
          <div className="flex flex-wrap justify-center items-center gap-4 text-xs font-bold pt-4 border-t border-slate-100">
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-md bg-emerald-50 border border-emerald-300 inline-block"></span>
              <span className="text-slate-600">Available</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-md bg-blue-600 inline-block"></span>
              <span className="text-blue-600">Selected</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-md bg-red-100 border border-red-200 inline-block"></span>
              <span className="text-red-500">Booked</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-md bg-pink-100 border border-pink-300 inline-block"></span>
              <span className="text-pink-600">Women Priority (Rows A-B)</span>
            </div>
          </div>
        </div>

        {/* Right: Booking Summary & Action */}
        <div className="md:col-span-4 space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <h3 className="text-base font-black text-slate-900 tracking-tight">
              Booking Overview
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Passenger Name</span>
                <span className="font-bold text-slate-900">{userProfile.name}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Bus Number</span>
                <span className="font-bold text-slate-900">{bus.busNumber}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Route</span>
                <span className="font-bold text-slate-900">{bus.fromLocation} → {bus.toLocation}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Selected Seat</span>
                <span className="font-extrabold text-blue-600 text-sm">
                  {selectedSeatNumber ? seatNumberBadge(selectedSeatNumber) : 'None'}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Double-Booking Lock</span>
                <span className="font-bold text-emerald-600 flex items-center gap-1">
                  <ShieldCheck size={14} /> Active
                </span>
              </div>
              <div className="flex justify-between py-2 pt-3 text-sm">
                <span className="font-bold text-slate-700">Total Payable</span>
                <span className="text-xl font-black text-slate-900">₹{bus.fare}</span>
              </div>
            </div>

            <button
              id="proceed-to-confirm-btn"
              onClick={handleProceed}
              disabled={!selectedSeatNumber}
              className={`w-full py-3.5 rounded-2xl font-bold text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer ${
                selectedSeatNumber
                  ? 'bg-blue-600 hover:bg-blue-700 active:scale-95 text-white shadow-blue-600/25'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span>{t.confirmBooking}</span>
              <ArrowRight size={16} />
            </button>
          </div>

          {/* Women Priority Tip */}
          <div className="bg-pink-50 border border-pink-200 p-4 rounded-2xl flex items-start gap-2.5 text-xs text-pink-900">
            <HeartHandshake size={18} className="text-pink-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Women Priority Seating</p>
              <p className="text-[11px] text-pink-800">
                Rows A & B are closer to the driver and CCTV panic alert monitors for comfortable and safe travel.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

const seatNumberBadge = (num: string) => {
  return (
    <span className="bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded font-black">
      {num}
    </span>
  );
};
