import React from 'react';
import { useApp } from '../context/AppContext';
import { Bus, CrowdLevel } from '../types';
import { 
  Bus as BusIcon, 
  MapPin, 
  Clock, 
  Users, 
  Armchair, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  ArrowRight, 
  Zap,
  ShieldCheck,
  BatteryCharging
} from 'lucide-react';

interface BusResultsProps {
  onSelectBusToBook: (bus: Bus) => void;
  onViewBusDetails: (bus: Bus) => void;
  onLiveTrackBus: (bus: Bus) => void;
}

export const BusResults: React.FC<BusResultsProps> = ({ 
  onSelectBusToBook, 
  onViewBusDetails,
  onLiveTrackBus 
}) => {
  const { filteredBuses, searchParams, t } = useApp();

  // Smart Recommendation Logic (Section 20: Smart Bus Recommendation)
  // Transparent demo logic: pick bus with lowest crowd, most seats, fastest ETA
  const recommendedBus = React.useMemo(() => {
    if (filteredBuses.length <= 1) return null;
    const sorted = [...filteredBuses].sort((a, b) => {
      // lower crowd percentage first
      if (a.crowdPercentage !== b.crowdPercentage) {
        return a.crowdPercentage - b.crowdPercentage;
      }
      // faster eta
      return a.etaMinutes - b.etaMinutes;
    });
    return sorted[0];
  }, [filteredBuses]);

  const getCrowdBadge = (level: CrowdLevel, percentage: number) => {
    switch (level) {
      case 'Low':
        return (
          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>🟢 Low Crowd ({percentage}%)</span>
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-1 rounded-full text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span>🟡 Medium Crowd ({percentage}%)</span>
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center gap-1 bg-red-50 text-red-700 border border-red-200 px-2.5 py-1 rounded-full text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-red-500"></span>
            <span>🔴 High Crowd ({percentage}%)</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Available Buses ({filteredBuses.length})
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Route: <span className="font-bold text-slate-700">{searchParams.from}</span> → <span className="font-bold text-slate-700">{searchParams.to}</span>
          </p>
        </div>
      </div>

      {/* Smart Bus Recommendation Card (Section 20) */}
      {recommendedBus && (
        <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100/60 border-2 border-emerald-400/80 rounded-3xl p-5 sm:p-6 shadow-sm">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 bg-emerald-600 text-white text-[11px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider shadow-xs">
                <Sparkles size={13} />
                <span>Smart Recommendation – {t.bestChoice}</span>
              </div>
              <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                <span>Bus {recommendedBus.busNumber}</span>
                <span className="text-xs font-normal text-emerald-800 bg-emerald-200/70 px-2 py-0.5 rounded-lg">
                  {recommendedBus.routeName}
                </span>
              </h3>
              <p className="text-xs sm:text-sm text-emerald-900 font-medium">
                {t.lessCrowdedMsg}
              </p>
              
              {/* Feature checkmarks */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs font-bold text-emerald-950">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                  <span>Lower crowd</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                  <span>{recommendedBus.availableSeats} Seats ready</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                  <span>Arriving in {recommendedBus.etaMinutes} min</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                  <span>Fixed ₹{recommendedBus.fare}</span>
                </div>
              </div>
            </div>

            <div className="flex sm:flex-col gap-2 w-full sm:w-auto shrink-0">
              <button
                onClick={() => onSelectBusToBook(recommendedBus)}
                className="flex-1 sm:flex-initial px-5 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-sm font-bold rounded-xl shadow-md shadow-emerald-600/20 transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>{t.bookSeat}</span>
                <ArrowRight size={16} />
              </button>
              <button
                onClick={() => onLiveTrackBus(recommendedBus)}
                className="flex-1 sm:flex-initial px-4 py-2.5 bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1"
              >
                <span>Track Live</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Buses List */}
      {filteredBuses.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 text-center border border-slate-200 shadow-sm space-y-3">
          <AlertCircle size={40} className="text-amber-500 mx-auto" />
          <h3 className="text-lg font-bold text-slate-800">No direct buses found for this route</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Try searching between major hubs like <span className="font-semibold text-slate-700">Tambaram</span> and <span className="font-semibold text-slate-700">Guindy</span> or <span className="font-semibold text-slate-700">Chennai Central</span>.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredBuses.map((bus) => {
            const isRec = recommendedBus?.id === bus.id;
            return (
              <div
                key={bus.id}
                id={`bus-card-${bus.busNumber.toLowerCase()}`}
                className={`bg-white rounded-3xl p-5 sm:p-6 border transition shadow-xs hover:shadow-md ${
                  isRec ? 'border-emerald-300 ring-1 ring-emerald-300/50' : 'border-slate-200 hover:border-blue-300'
                }`}
              >
                <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-5">
                  
                  {/* Left: Bus identifier & route info */}
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-base shadow-sm">
                        {bus.busNumber}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-black text-slate-900 tracking-tight">
                            Bus {bus.busNumber}
                          </h3>
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                            bus.status === 'On Time' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {bus.status === 'On Time' ? '🟢 On Time' : '🟡 Delayed'}
                          </span>
                          {bus.isElectric && (
                            <span className="text-[10px] font-bold bg-teal-100 text-teal-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <BatteryCharging size={11} /> EV {bus.batteryPercentage}%
                            </span>
                          )}
                          <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                            {bus.acType}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 font-semibold mt-0.5">
                          {bus.fromLocation} → {bus.toLocation}
                        </p>
                      </div>
                    </div>

                    {/* Metadata Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
                      <div className="flex items-center gap-2 text-slate-600">
                        <MapPin size={15} className="text-blue-600 shrink-0" />
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase font-semibold">Current Loc</p>
                          <p className="font-bold text-slate-800 truncate">{bus.currentLocation}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-slate-600">
                        <Clock size={15} className="text-amber-500 shrink-0" />
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase font-semibold">ETA to Stop</p>
                          <p className="font-bold text-slate-800">⏱ {bus.etaMinutes} min</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-slate-600">
                        <Armchair size={15} className="text-emerald-600 shrink-0" />
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase font-semibold">Available</p>
                          <p className="font-bold text-emerald-700">{bus.availableSeats} Seats Left</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-slate-600">
                        <Users size={15} className="text-purple-600 shrink-0" />
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase font-semibold">Crowd</p>
                          <div className="mt-0.5">{getCrowdBadge(bus.crowdLevel, bus.crowdPercentage)}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right: Fare and Actions */}
                  <div className="flex sm:flex-row lg:flex-col justify-between items-end lg:items-end gap-3 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                    <div className="text-left sm:text-right">
                      <p className="text-2xl font-black text-slate-900">₹{bus.fare}</p>
                      <p className="text-[11px] text-slate-400 font-semibold">Single Standard Fare</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onViewBusDetails(bus)}
                        className="px-3.5 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition"
                      >
                        {t.viewBus}
                      </button>

                      <button
                        onClick={() => onLiveTrackBus(bus)}
                        className="px-3.5 py-2.5 rounded-xl border border-slate-200 hover:bg-blue-50 text-blue-600 text-xs font-bold transition flex items-center gap-1"
                        title="Live GPS Track"
                      >
                        <span>Map</span>
                      </button>

                      <button
                        id={`book-bus-${bus.busNumber.toLowerCase()}-btn`}
                        onClick={() => onSelectBusToBook(bus)}
                        className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-600/20 transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>{t.bookSeat}</span>
                        <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
