import React from 'react';
import { useApp } from '../context/AppContext';
import { Bell, MapPin, CheckCircle2, X } from 'lucide-react';

export const DestinationAlertModal: React.FC = () => {
  const { activeDestinationAlert, dismissDestinationAlert } = useApp();

  if (!activeDestinationAlert) return null;

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 max-w-sm w-full bg-slate-900 text-white rounded-3xl p-5 shadow-2xl border-2 border-amber-400 animate-bounce-short">
      <div className="flex items-start justify-between gap-3">
        <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
          <Bell size={20} className="animate-pulse" />
        </div>

        <div className="space-y-1 grow">
          <div className="flex items-center gap-1 text-[11px] font-mono text-amber-400 font-bold uppercase">
            <MapPin size={12} />
            <span>Destination Approaching</span>
          </div>
          <h4 className="font-extrabold text-sm text-white">
            {activeDestinationAlert.destination} is {activeDestinationAlert.stopsAway} stops away!
          </h4>
          <p className="text-xs text-slate-300 font-medium leading-relaxed">
            Bus {activeDestinationAlert.busNumber} is nearing your scheduled stop. Please prepare to alight.
          </p>
        </div>

        <button
          onClick={dismissDestinationAlert}
          className="text-slate-400 hover:text-white p-1"
        >
          <X size={16} />
        </button>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-800 flex justify-end gap-2">
        <button
          onClick={dismissDestinationAlert}
          className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition"
        >
          Got It, Thanks!
        </button>
      </div>
    </div>
  );
};
