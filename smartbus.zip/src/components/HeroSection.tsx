import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Bus as BusIcon, 
  MapPin, 
  Users, 
  Ticket, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles, 
  Navigation, 
  Clock, 
  Zap, 
  ShieldAlert
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { setActiveView, t, buses, setSelectedBus } = useApp();

  const handleTrackQuick = (busId: string) => {
    const found = buses.find(b => b.id === busId);
    if (found) {
      setSelectedBus(found);
      setActiveView('live');
    }
  };

  return (
    <section className="relative overflow-hidden pt-6 pb-12 sm:pb-16 bg-gradient-to-b from-blue-50/70 via-slate-50 to-white">
      {/* Decorative ambient elements */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 bg-blue-100/80 border border-blue-200/80 text-blue-900 px-3.5 py-1.5 rounded-full text-xs font-semibold">
              <Sparkles size={14} className="text-blue-600" />
              <span>Next-Gen Public Transportation Architecture</span>
            </div>

            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]">
                {t.heroTitle}
              </h1>
              <p className="text-base sm:text-lg text-slate-600 font-normal leading-relaxed max-w-2xl">
                {t.heroSubtitle}
              </p>
            </div>

            {/* Main Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                id="hero-find-bus-btn"
                onClick={() => setActiveView('search')}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-6 py-3.5 rounded-xl font-bold text-sm sm:text-base shadow-lg shadow-blue-600/25 transition cursor-pointer"
              >
                <span>{t.findMyBus}</span>
                <ArrowRight size={18} />
              </button>

              <button
                id="hero-track-live-btn"
                onClick={() => setActiveView('live')}
                className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 px-6 py-3.5 rounded-xl font-bold text-sm sm:text-base shadow-xs hover:border-slate-400 transition cursor-pointer"
              >
                <Navigation size={18} className="text-emerald-600" />
                <span>{t.trackLiveBus}</span>
              </button>
            </div>

            {/* Quick status badges */}
            <div className="pt-4 flex flex-wrap items-center gap-4 text-xs font-medium text-slate-500 border-t border-slate-200/80">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>5 Live Routes Active</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Zap size={14} className="text-amber-500" />
                <span>Double-Booking Guaranteed Prevention</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-emerald-600" />
                <span>Instant QR Boarding Verification</span>
              </div>
            </div>
          </div>

          {/* Right Visual Card (Interactive Transit Radar) */}
          <div className="lg:col-span-5">
            <div className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-blue-950 text-white rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-700/50">
              
              {/* Bus Visual Header */}
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-emerald-400 font-bold uppercase">
                    SIMULATED RADAR
                  </span>
                  <h3 className="text-xl font-black text-white flex items-center gap-2 mt-0.5">
                    <span>Bus 21G</span>
                    <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                      On Time
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300 font-medium">Tambaram ⇄ Guindy (GST Rd)</p>
                </div>

                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300">
                  <BusIcon size={20} />
                </div>
              </div>

              {/* Progress Line */}
              <div className="space-y-4 mb-6">
                <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-700">
                  <div className="relative flex items-center justify-between text-xs">
                    <span className="absolute -left-6 w-4 h-4 rounded-full bg-slate-600 border-2 border-slate-900"></span>
                    <span className="text-slate-400 font-medium">Tambaram Sanatorium</span>
                    <span className="text-slate-400 font-mono text-[11px]">Passed</span>
                  </div>

                  <div className="relative flex items-center justify-between text-xs font-bold">
                    <span className="absolute -left-6 w-4 h-4 rounded-full bg-emerald-400 border-2 border-slate-900 animate-pulse"></span>
                    <span className="text-emerald-300">Chromepet (Current Stop)</span>
                    <span className="text-emerald-400 font-mono text-[11px]">Now</span>
                  </div>

                  <div className="relative flex items-center justify-between text-xs">
                    <span className="absolute -left-6 w-4 h-4 rounded-full bg-blue-500 border-2 border-slate-900"></span>
                    <span className="text-slate-300 font-medium">Pallavaram</span>
                    <span className="text-blue-400 font-mono font-bold">ETA 6 min</span>
                  </div>

                  <div className="relative flex items-center justify-between text-xs">
                    <span className="absolute -left-6 w-4 h-4 rounded-full bg-slate-600 border-2 border-slate-900"></span>
                    <span className="text-slate-400 font-medium">Guindy Kathipara</span>
                    <span className="text-slate-400 font-mono">24 min</span>
                  </div>
                </div>
              </div>

              {/* Micro stats grid */}
              <div className="grid grid-cols-3 gap-2 p-3 bg-slate-800/80 rounded-2xl border border-slate-700/60 text-center mb-4">
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Crowd</p>
                  <p className="text-xs font-bold text-amber-300 mt-0.5">🟡 Medium</p>
                </div>
                <div className="border-x border-slate-700">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Available</p>
                  <p className="text-xs font-bold text-emerald-400 mt-0.5">12 Seats</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Fare</p>
                  <p className="text-xs font-bold text-white mt-0.5">₹20</p>
                </div>
              </div>

              {/* Quick action within card */}
              <button
                onClick={() => handleTrackQuick('bus-21g')}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 active:scale-98 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md"
              >
                <span>View Full Map & Live Track</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* 4 Feature Cards as explicitly requested */}
        <div className="mt-12 sm:mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          
          {/* Card 1 */}
          <div 
            onClick={() => setActiveView('live')}
            className="group bg-white rounded-2xl p-5 border border-slate-200 hover:border-blue-300 hover:shadow-md transition cursor-pointer text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4 group-hover:scale-105 group-hover:bg-blue-600 group-hover:text-white transition">
              <BusIcon size={24} />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-1">🚌 Live Bus Tracking</h3>
            <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
              Track approximate live GPS positions, next stops, and accurate countdown arrival times.
            </p>
          </div>

          {/* Card 2 */}
          <div 
            onClick={() => setActiveView('search')}
            className="group bg-white rounded-2xl p-5 border border-slate-200 hover:border-amber-300 hover:shadow-md transition cursor-pointer text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4 group-hover:scale-105 group-hover:bg-amber-500 group-hover:text-white transition">
              <Users size={24} />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-1">👥 Crowd Information</h3>
            <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
              Know current crowd levels (Low, Medium, High) and get smart suggestions for less crowded buses.
            </p>
          </div>

          {/* Card 3 */}
          <div 
            onClick={() => setActiveView('search')}
            className="group bg-white rounded-2xl p-5 border border-slate-200 hover:border-emerald-300 hover:shadow-md transition cursor-pointer text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 group-hover:scale-105 group-hover:bg-emerald-600 group-hover:text-white transition">
              <Ticket size={24} />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-1">🎫 Easy Booking</h3>
            <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
              Interactive seat coach layout with guaranteed atomic double-booking lock and instant QR tickets.
            </p>
          </div>

          {/* Card 4 */}
          <div 
            onClick={() => setActiveView('safety')}
            className="group bg-white rounded-2xl p-5 border border-slate-200 hover:border-pink-300 hover:shadow-md transition cursor-pointer text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center mb-4 group-hover:scale-105 group-hover:bg-pink-600 group-hover:text-white transition">
              <ShieldCheck size={24} />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-1">🛡️ Passenger Safety</h3>
            <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
              One-tap SOS, automated Women Safety check-ins, trip sharing, and destination arrival alerts.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
