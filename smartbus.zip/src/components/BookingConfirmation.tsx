import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bus } from '../types';
import confetti from 'canvas-confetti';
import { 
  CheckCircle2, 
  ArrowLeft, 
  ShieldCheck, 
  CreditCard, 
  Smartphone, 
  Zap, 
  Lock,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface BookingConfirmationProps {
  bus: Bus;
  seatNumber: string;
  onBack: () => void;
  onBookingSuccess: () => void;
}

export const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  bus,
  seatNumber,
  onBack,
  onBookingSuccess
}) => {
  const { userProfile, bookSeat, searchParams, showToast } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'wallet'>('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);

  const handlePayAndConfirm = async () => {
    setIsProcessing(true);
    setBookingError(null);

    // Simulate realistic 600ms network & atomic double-booking check
    try {
      const result = await bookSeat(bus.id, seatNumber);

      if (result.success) {
        // Trigger celebratory confetti
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
        showToast('🎉 Booking Confirmed! Digital QR Ticket Generated.', 'success');
        onBookingSuccess();
      } else {
        setBookingError(result.error || 'Failed to complete booking. Please select another seat.');
        showToast(result.error || 'Seat booking conflict', 'error');
      }
    } catch (err) {
      setBookingError('Unexpected error during booking.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Top Header */}
      <div className="flex items-center gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition"
        >
          <ArrowLeft size={18} />
        </button>
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            Review & Confirm Booking
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Standard Fare Reservation • Instant QR Ticket
          </p>
        </div>
      </div>

      {bookingError && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-2xl flex items-center gap-3 text-sm font-bold animate-shake">
          <AlertCircle size={20} className="shrink-0 text-red-600" />
          <span>{bookingError}</span>
        </div>
      )}

      {/* Ticket Details Summary Card */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-5">
        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white font-black text-lg flex items-center justify-center">
              {bus.busNumber}
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Bus {bus.busNumber}
              </h3>
              <p className="text-xs text-slate-500 font-medium">{bus.routeName}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-bold text-slate-400 block uppercase">Fare</span>
            <span className="text-2xl font-black text-slate-900">₹{bus.fare}</span>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-slate-400 font-bold block uppercase text-[10px]">Route Departure</span>
            <span className="font-black text-slate-900 text-sm mt-0.5 block">{bus.fromLocation}</span>
            <span className="text-slate-500">To {bus.toLocation}</span>
          </div>

          <div className="bg-blue-50/70 p-3 rounded-2xl border border-blue-100">
            <span className="text-blue-600 font-bold block uppercase text-[10px]">Seat Number</span>
            <span className="font-black text-blue-900 text-base mt-0.5 block">Seat {seatNumber}</span>
            <span className="text-blue-700">Reserved For You</span>
          </div>

          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-slate-400 font-bold block uppercase text-[10px]">Passenger</span>
            <span className="font-bold text-slate-900 text-xs mt-0.5 block">{userProfile.name}</span>
            <span className="text-slate-500">{userProfile.phone}</span>
          </div>

          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-slate-400 font-bold block uppercase text-[10px]">Travel Date</span>
            <span className="font-bold text-slate-900 text-xs mt-0.5 block">{searchParams.date || 'Today'}</span>
            <span className="text-emerald-600 font-bold">Estimated Arrival: 15 min</span>
          </div>
        </div>

        {/* Demo Simulated Payment Methods */}
        <div className="space-y-3 pt-2">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Select Demo Payment Method
            </h4>
            <span className="text-[10px] bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded">
              Prototype Mode (No Real Money Charged)
            </span>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setPaymentMethod('upi')}
              className={`p-3.5 rounded-2xl border text-left transition ${
                paymentMethod === 'upi'
                  ? 'border-blue-600 bg-blue-50/60 ring-2 ring-blue-600/30'
                  : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
              }`}
            >
              <Smartphone size={18} className={paymentMethod === 'upi' ? 'text-blue-600' : 'text-slate-500'} />
              <p className="font-extrabold text-xs text-slate-900 mt-2">Instant UPI</p>
              <p className="text-[10px] text-slate-500">GPay / PhonePe (Demo)</p>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('card')}
              className={`p-3.5 rounded-2xl border text-left transition ${
                paymentMethod === 'card'
                  ? 'border-blue-600 bg-blue-50/60 ring-2 ring-blue-600/30'
                  : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
              }`}
            >
              <CreditCard size={18} className={paymentMethod === 'card' ? 'text-blue-600' : 'text-slate-500'} />
              <p className="font-extrabold text-xs text-slate-900 mt-2">Transit Card</p>
              <p className="text-[10px] text-slate-500">Smart Transit Pass</p>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('wallet')}
              className={`p-3.5 rounded-2xl border text-left transition ${
                paymentMethod === 'wallet'
                  ? 'border-blue-600 bg-blue-50/60 ring-2 ring-blue-600/30'
                  : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
              }`}
            >
              <Zap size={18} className={paymentMethod === 'wallet' ? 'text-blue-600' : 'text-slate-500'} />
              <p className="font-extrabold text-xs text-slate-900 mt-2">Fast Pay</p>
              <p className="text-[10px] text-slate-500">1-Click Simulated</p>
            </button>
          </div>
        </div>

        {/* Security / Concurrency note */}
        <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-3 rounded-xl">
          <Lock size={14} className="text-emerald-600 shrink-0" />
          <span>Atomic lock active: Prevents duplicate bookings across all conductor & passenger devices.</span>
        </div>

        {/* Pay & Confirm Action */}
        <button
          id="confirm-pay-btn"
          onClick={handlePayAndConfirm}
          disabled={isProcessing}
          className="w-full py-4 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-black text-base rounded-2xl shadow-xl shadow-blue-600/25 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          {isProcessing ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Securing Seat & Generating QR...</span>
            </>
          ) : (
            <>
              <span>Pay ₹{bus.fare} & Generate QR Ticket</span>
              <CheckCircle2 size={20} />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
