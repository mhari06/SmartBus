import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Bus, 
  Shield, 
  User, 
  PhoneCall, 
  MapPin, 
  Ticket, 
  History, 
  Sliders, 
  Languages, 
  Eye, 
  AlertTriangle,
  Menu,
  X,
  Sparkles,
  HeartHandshake
} from 'lucide-react';
import { SupportedLanguage } from '../types';

interface NavbarProps {
  onOpenProfile: () => void;
  onOpenSOSModal: () => void;
  onOpenReportModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenProfile, onOpenSOSModal, onOpenReportModal }) => {
  const { 
    activeView, 
    setActiveView, 
    language, 
    setLanguage, 
    t, 
    userProfile, 
    updateUserProfile,
    bookings,
    activeDestinationAlert
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const activeTicketsCount = bookings.filter(b => b.bookingStatus === 'BOOKED').length;

  const languagesList: { code: SupportedLanguage; label: string; native: string }[] = [
    { code: 'English', label: 'English', native: 'English' },
    { code: 'Tamil', label: 'Tamil', native: 'தமிழ்' },
    { code: 'Hindi', label: 'Hindi', native: 'हिंदी' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top micro-bar with demo banner & quick toggles */}
      <div className="bg-slate-900 text-slate-200 px-4 py-1.5 text-xs flex justify-between items-center">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-mono text-emerald-400 font-semibold tracking-wide uppercase text-[10px] sm:text-xs">
            LIVE TRANSIT NETWORK
          </span>
          <span className="hidden sm:inline text-slate-400">|</span>
          <span className="hidden md:inline text-slate-300 truncate">
            {t.demoNotice}
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {/* Women Safety Mode Indicator */}
          {userProfile.womenSafetyMode && (
            <button
              onClick={() => setActiveView('women-safety')}
              className="flex items-center gap-1 bg-pink-500/20 text-pink-300 hover:bg-pink-500/30 px-2 py-0.5 rounded text-[11px] font-medium transition"
              title="Women Safety Mode Active"
            >
              <HeartHandshake size={12} className="text-pink-400" />
              <span className="hidden sm:inline">Women Safety Active</span>
            </button>
          )}

          {/* Accessibility Mode Toggle */}
          <button
            onClick={() => updateUserProfile({ accessibilityMode: !userProfile.accessibilityMode })}
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] transition ${
              userProfile.accessibilityMode ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
            }`}
            title="Toggle Large Text / Accessibility Mode"
          >
            <Eye size={12} />
            <span className="hidden sm:inline">A11y</span>
          </button>

          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              className="flex items-center gap-1 text-slate-200 hover:text-white px-2 py-0.5 rounded bg-slate-800 text-[11px] font-medium"
            >
              <Languages size={12} />
              <span>{language}</span>
            </button>

            {langDropdownOpen && (
              <div className="absolute right-0 mt-1 w-32 bg-white rounded-lg shadow-xl border border-slate-200 py-1 text-slate-800 z-50">
                {languagesList.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setLanguage(lang.code);
                      setLangDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-xs flex justify-between items-center hover:bg-slate-100 ${
                      language === lang.code ? 'font-bold text-blue-600 bg-blue-50' : ''
                    }`}
                  >
                    <span>{lang.native}</span>
                    <span className="text-[10px] text-slate-400">{lang.code}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setActiveView('home')} 
            className="flex items-center gap-2.5 text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition">
              <Bus size={22} className="group-hover:scale-105 transition transform" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl text-slate-900 tracking-tight leading-none">SmartBus</span>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.5 rounded uppercase">2030</span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium leading-none mt-0.5">Safe & Smart Transit</p>
            </div>
          </button>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 text-sm font-semibold text-slate-600">
          <button
            onClick={() => setActiveView('home')}
            className={`px-3 py-2 rounded-lg transition ${
              activeView === 'home' ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => setActiveView('search')}
            className={`px-3 py-2 rounded-lg transition ${
              activeView === 'search' ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Find Bus
          </button>

          <button
            onClick={() => setActiveView('live')}
            className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
              activeView === 'live' ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            Live Buses
          </button>

          <button
            onClick={() => setActiveView('tickets')}
            className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
              activeView === 'tickets' ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Ticket size={16} />
            <span>My Tickets</span>
            {activeTicketsCount > 0 && (
              <span className="bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                {activeTicketsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveView('trips')}
            className={`px-3 py-2 rounded-lg transition ${
              activeView === 'trips' ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            My Trips
          </button>

          <button
            onClick={() => setActiveView('safety')}
            className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
              activeView === 'safety' ? 'text-blue-600 bg-blue-50' : 'hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Shield size={16} className="text-emerald-600" />
            <span>Safety</span>
          </button>

          <button
            onClick={() => setActiveView('women-safety')}
            className={`px-3 py-2 rounded-lg transition flex items-center gap-1.5 ${
              activeView === 'women-safety' ? 'text-pink-600 bg-pink-50' : 'hover:text-pink-600 hover:bg-pink-50/50'
            }`}
          >
            <HeartHandshake size={16} className="text-pink-600" />
            <span>Women Mode</span>
          </button>

          <div className="h-4 w-px bg-slate-200 mx-1"></div>

          <button
            onClick={() => setActiveView('conductor')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
              activeView === 'conductor' 
                ? 'bg-slate-900 text-white' 
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Conductor
          </button>

          <button
            onClick={() => setActiveView('admin')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition ${
              activeView === 'admin' 
                ? 'bg-indigo-600 text-white' 
                : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100'
            }`}
          >
            Admin
          </button>
        </nav>

        {/* Right CTA / SOS / Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Destination Alert Indicator if active */}
          {activeDestinationAlert && (
            <div className="hidden sm:flex items-center gap-1.5 bg-amber-50 border border-amber-200 text-amber-900 text-xs px-2.5 py-1 rounded-full animate-pulse">
              <MapPin size={13} className="text-amber-600" />
              <span className="font-semibold">{activeDestinationAlert.destination} ({activeDestinationAlert.stopsAway} stops)</span>
            </div>
          )}

          {/* Emergency SOS Button */}
          <button
            id="nav-sos-button"
            onClick={onOpenSOSModal}
            className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 active:scale-95 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-red-500/25 transition cursor-pointer"
          >
            <PhoneCall size={16} className="animate-bounce" />
            <span>{t.sosEmergency}</span>
          </button>

          {/* Profile Trigger */}
          <button
            onClick={onOpenProfile}
            className="w-10 h-10 rounded-xl border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition"
            title="Passenger Profile & Settings"
          >
            <User size={18} />
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-6 space-y-2 shadow-lg">
          <div className="grid grid-cols-2 gap-2 text-sm font-semibold pt-2">
            <button
              onClick={() => { setActiveView('home'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-slate-50 hover:bg-slate-100 text-left"
            >
              🏠 Home
            </button>
            <button
              onClick={() => { setActiveView('search'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-slate-50 hover:bg-slate-100 text-left"
            >
              🔍 Find Bus
            </button>
            <button
              onClick={() => { setActiveView('live'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-slate-50 hover:bg-slate-100 text-left"
            >
              📍 Live Tracking
            </button>
            <button
              onClick={() => { setActiveView('tickets'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-slate-50 hover:bg-slate-100 text-left"
            >
              🎫 My Tickets ({activeTicketsCount})
            </button>
            <button
              onClick={() => { setActiveView('trips'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-slate-50 hover:bg-slate-100 text-left"
            >
              🕒 My Trips
            </button>
            <button
              onClick={() => { setActiveView('safety'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-emerald-50 text-emerald-900 hover:bg-emerald-100 text-left font-bold"
            >
              🛡️ Safety Center
            </button>
            <button
              onClick={() => { setActiveView('women-safety'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-pink-50 text-pink-900 hover:bg-pink-100 text-left font-bold"
            >
              👩 Women Safety
            </button>
            <button
              onClick={() => { setActiveView('conductor'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-slate-900 text-white hover:bg-slate-800 text-left font-bold"
            >
              🎫 Conductor Mode
            </button>
            <button
              onClick={() => { setActiveView('admin'); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-indigo-50 text-indigo-900 hover:bg-indigo-100 text-left font-bold"
            >
              ⚙️ Admin Panel
            </button>
            <button
              onClick={() => { onOpenReportModal(); setMobileMenuOpen(false); }}
              className="p-3 rounded-lg bg-amber-50 text-amber-900 hover:bg-amber-100 text-left"
            >
              ⚠️ Report Issue
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
