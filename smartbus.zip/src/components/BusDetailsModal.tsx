import React from 'react';
import { Bus } from '../types';
import { 
  X, 
  MapPin, 
  Clock, 
  Users, 
  Armchair, 
  ShieldCheck, 
  BatteryCharging, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  Zap
} from 'lucide-react';
import { CrowdPredictor } from './CrowdPredictor';

interface BusDetailsModalProps {
  bus: Bus;
  onClose: () => void;
  onBookSeat: (bus: Bus) => void;
}

export const BusDetailsModal: React.FC<BusDetailsModalProps> = ({ bus, onClose, onBookSeat }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 text-left">
        
        {/* Header */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md px-6 py-5 border-b border-slate-200 flex justify-between items-center z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white font-black text-lg flex items-center justify-center shadow-md">
              {bus.busNumber}
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900 leading-tight">
                Bus {bus.busNumber} Details
              </h2>
              <p className="text-xs text-slate-500 font-medium">{bus.routeName}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center">
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Fare</p>
              <p className="text-lg font-black text-slate-900">₹{bus.fare}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Seats Free</p>
              <p className="text-lg font-black text-emerald-600">{bus.availableSeats} / {bus.totalSeats}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Status</p>
              <p className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-1 rounded-full inline-block mt-1">
                {bus.status}
              </p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Safety Index</p>
              <p className="text-lg font-black text-blue-600">★ {bus.safetyRating} / 5.0</p>
            </div>
          </div>

          {/* Safety Features Onboard */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Onboard Amenities & Safety Certified
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-semibold text-slate-700">
              <div className="flex items-center gap-2 p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-200 text-emerald-950">
                <ShieldCheck size={16} className="text-emerald-600" />
                <span>CCTV & Panic Buttons</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-pink-50/60 rounded-xl border border-pink-200 text-pink-950">
                <ShieldCheck size={16} className="text-pink-600" />
                <span>Women Priority Seating</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-blue-50/60 rounded-xl border border-blue-200 text-blue-950">
                <Zap size={16} className="text-blue-600" />
                <span>GPS Live Telemetry</span>
              </div>
            </div>
          </div>

          {/* Route Stops Timeline */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Scheduled Stops & Timeline
            </h3>

            <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {bus.stops.map((stop, idx) => {
                const isFirst = idx === 0;
                const isLast = idx === bus.stops.length - 1;
                return (
                  <div key={stop.id} className="relative flex justify-between items-center text-xs">
                    <span className={`absolute -left-6 w-4 h-4 rounded-full border-2 border-white ${
                      isFirst ? 'bg-blue-600' : isLast ? 'bg-red-500' : 'bg-slate-400'
                    }`}></span>
                    <div>
                      <p className="font-bold text-slate-900">{stop.name}</p>
                      <p className="text-[10px] text-slate-400">{isFirst ? 'Origin Terminal' : isLast ? 'Final Destination' : `Intermediate Stop #${idx + 1}`}</p>
                    </div>
                    <span className="font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      +{stop.etaFromStart} min
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Crowd Predictor Component */}
          <CrowdPredictor bus={bus} />

        </div>

        {/* Footer Actions */}
        <div className="p-6 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
          <div>
            <p className="text-xs text-slate-500 font-semibold">Standard One-Seat Fare</p>
            <p className="text-2xl font-black text-slate-900">₹{bus.fare}</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold transition"
            >
              Close
            </button>

            <button
              onClick={() => {
                onClose();
                onBookSeat(bus);
              }}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-sm font-bold shadow-md shadow-blue-600/20 transition flex items-center gap-2 cursor-pointer"
            >
              <span>Select Seat & Book</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
