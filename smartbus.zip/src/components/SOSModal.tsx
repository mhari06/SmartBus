import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  AlertTriangle, 
  PhoneCall, 
  X, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  ShieldAlert, 
  UserCheck 
} from 'lucide-react';

interface SOSModalProps {
  onClose: () => void;
}

export const SOSModal: React.FC<SOSModalProps> = ({ onClose }) => {
  const { triggerSOS, userProfile, selectedBus } = useApp();
  
  // Step 1: Confirmation -> Step 2: Dispatched
  const [step, setStep] = useState<'confirm' | 'dispatched'>('confirm');
  const [activeAlertDetails, setActiveAlertDetails] = useState<any>(null);

  const handleConfirmSOS = () => {
    const alert = triggerSOS(
      selectedBus?.busNumber || '21G',
      'Chromepet GST Road (Near Metro Station)'
    );
    setActiveAlertDetails(alert);
    setStep('dispatched');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-red-200 text-center">
        
        {/* Modal Header */}
        <div className="bg-red-600 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition"
          >
            <X size={16} />
          </button>

          <div className="w-14 h-14 rounded-2xl bg-white text-red-600 flex items-center justify-center mx-auto mb-3 shadow-lg">
            <PhoneCall size={28} className="animate-bounce" />
          </div>

          <h2 className="text-xl font-black tracking-tight">
            {step === 'confirm' ? 'Confirm Emergency SOS' : '🚨 SOS Alert Dispatched!'}
          </h2>
          <p className="text-xs text-red-100 mt-1">
            {step === 'confirm' ? '2-Step Verification to Prevent Accidental Triggers' : 'Emergency Assistance En Route'}
          </p>
        </div>

        {/* Step 1: 2-Step Confirmation */}
        {step === 'confirm' ? (
          <div className="p-6 space-y-5">
            <div className="p-4 bg-red-50 rounded-2xl border border-red-100 text-left space-y-2 text-xs text-red-900">
              <div className="flex items-center gap-1.5 font-bold">
                <AlertTriangle size={15} className="text-red-600 shrink-0" />
                <span>What happens when you confirm:</span>
              </div>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-red-800">
                <li>Immediate GPS dispatch to Chennai Transport Control Room.</li>
                <li>Instant SMS alert dispatched to your guardian: <strong>{userProfile.emergencyContact.name} ({userProfile.emergencyContact.phone})</strong>.</li>
                <li>Driver & Conductor on Bus <strong>{selectedBus?.busNumber || '21G'}</strong> receive flashing cabin alert.</li>
              </ul>
            </div>

            <p className="text-xs font-semibold text-slate-500">
              Are you sure you want to trigger the emergency alert now?
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
              >
                Cancel / False Alarm
              </button>

              <button
                id="confirm-sos-step2-btn"
                type="button"
                onClick={handleConfirmSOS}
                className="py-3.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-lg shadow-red-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <PhoneCall size={14} />
                <span>CONFIRM SOS</span>
              </button>
            </div>
          </div>
        ) : (
          /* Step 2: Emergency Dispatched State */
          <div className="p-6 space-y-5">
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-left space-y-2 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-emerald-900">
                <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                <span>Emergency Signals Active</span>
              </div>
              <div className="text-slate-600 space-y-1 text-[11px]">
                <p>📍 Location: <strong>Chromepet GST Road (12.9516, 80.1462)</strong></p>
                <p>🚌 Vehicle: <strong>Bus {selectedBus?.busNumber || '21G'}</strong></p>
                <p>📞 Contact: <strong>{userProfile.emergencyContact.name} notified via SMS</strong></p>
                <p>⏱ Timestamp: <strong>{new Date().toLocaleTimeString()}</strong></p>
              </div>
            </div>

            <div className="p-3 bg-slate-100 rounded-xl text-xs text-slate-700 font-semibold">
              Dial Transport Emergency Helpline (Prototype Demo): <strong className="text-blue-600">112 / 1091</strong>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition"
            >
              Acknowledge & Close Window
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
