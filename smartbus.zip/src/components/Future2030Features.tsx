import React from 'react';
import { 
  Sparkles, 
  BatteryCharging, 
  BrainCircuit, 
  Leaf, 
  Train, 
  Bus as BusIcon, 
  ShieldCheck, 
  X,
  Zap
} from 'lucide-react';

interface Future2030FeaturesProps {
  onClose: () => void;
}

export const Future2030Features: React.FC<Future2030FeaturesProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 text-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-800 space-y-6 text-left relative max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex justify-between items-start pb-4 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-1.5 bg-blue-500/20 text-blue-300 border border-blue-400/30 px-3 py-1 rounded-full text-xs font-bold uppercase mb-1">
              <Sparkles size={14} className="text-blue-400" />
              <span>SmartBus 2030 Transit Vision</span>
            </div>
            <h2 className="text-2xl font-black text-white">
              Next-Gen Public Transportation Architecture
            </h2>
            <p className="text-xs text-slate-400">
              Future-proof capabilities built into the SmartBus transit engine
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X size={16} />
          </button>
        </div>

        {/* 4 Pillars of 2030 Tech */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Feature 1 */}
          <div className="p-5 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center">
              <BrainCircuit size={22} />
            </div>
            <h3 className="font-extrabold text-base text-white">AI Crowd & Density Forecasting</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Real-time deep learning models predict coach occupancy along routes 30–60 minutes in advance, suggesting less-crowded alternative buses.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="p-5 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center">
              <BatteryCharging size={22} />
            </div>
            <h3 className="font-extrabold text-base text-white">EV Fleet Telemetry & Battery Health</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every electric bus transmits battery state-of-charge, regenerative braking efficiency, and depot supercharging status in real-time.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="p-5 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
              <Leaf size={22} />
            </div>
            <h3 className="font-extrabold text-base text-white">Personal Eco-Transit & Carbon Ledger</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Calculates individual passenger carbon emission savings against private car journeys and awards transit green credits.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="p-5 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-2">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center">
              <Train size={22} />
            </div>
            <h3 className="font-extrabold text-base text-white">Multi-Modal Metro + Bus Interconnect</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Seamlessly blends Chennai Metro schedules with feeder bus departures, enabling single QR ticket journeys across train and road transport.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition"
          >
            Close 2030 Preview
          </button>
        </div>

      </div>
    </div>
  );
};
