import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ShieldAlert, 
  PhoneCall, 
  Share2, 
  UserCheck, 
  Bell, 
  AlertTriangle, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  HeartHandshake,
  Copy,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

interface SafetyCenterProps {
  onOpenSOSModal: () => void;
  onOpenReportModal: () => void;
}

export const SafetyCenter: React.FC<SafetyCenterProps> = ({ onOpenSOSModal, onOpenReportModal }) => {
  const { 
    userProfile, 
    updateUserProfile, 
    safetyAlerts, 
    triggerSOS, 
    lastConfirmedBooking, 
    showToast 
  } = useApp();

  const [copiedLink, setCopiedLink] = useState(false);
  const [editingContact, setEditingContact] = useState(false);
  const [contactName, setContactName] = useState(userProfile.emergencyContact.name);
  const [contactPhone, setContactPhone] = useState(userProfile.emergencyContact.phone);
  const [contactRel, setContactRel] = useState(userProfile.emergencyContact.relationship);

  const handleCopyTripShare = () => {
    const link = `${window.location.origin}/#live-safety-trip?id=${userProfile.id}&bus=21G`;
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    showToast('Secure Live Trip link copied to clipboard! 📋', 'success');
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleSaveContact = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      emergencyContact: {
        name: contactName,
        phone: contactPhone,
        relationship: contactRel
      }
    });
    setEditingContact(false);
    showToast('Emergency contact details saved.', 'success');
  };

  return (
    <div className="space-y-8">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-br from-red-600 via-rose-600 to-red-700 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider">
              <ShieldAlert size={14} />
              <span>Smart Transit Emergency & Safety Center</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Passenger Protection Hub
            </h2>
            <p className="text-xs sm:text-sm text-red-100 max-w-xl">
              24/7 simulated emergency response, automated location telemetry sharing, and verified women passenger safety mechanisms.
            </p>
          </div>

          {/* Large SOS Button with 2-step confirmation modal trigger */}
          <button
            id="safety-center-sos-btn"
            onClick={onOpenSOSModal}
            className="w-full md:w-auto px-8 py-5 bg-white hover:bg-red-50 text-red-600 active:scale-95 rounded-2xl font-black text-lg sm:text-xl shadow-2xl transition flex items-center justify-center gap-3 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center group-hover:scale-110 transition">
              <PhoneCall size={18} className="animate-bounce" />
            </div>
            <span>TRIGGER SOS EMERGENCY</span>
          </button>
        </div>
      </div>

      {/* Safety Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Live Sharing & Contacts */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Live Trip Sharing Card */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <Share2 size={20} />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-slate-900">
                  Live Trip Location Sharing
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Share real-time tracking link with family, friends, or trusted guardians.
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="space-y-0.5">
                <p className="text-xs font-mono font-bold text-slate-700 truncate max-w-xs">
                  {window.location.origin}/#live-safety-trip?id={userProfile.id}
                </p>
                <p className="text-[11px] text-emerald-600 font-bold">
                  🟢 Real-time GPS stream active
                </p>
              </div>

              <button
                onClick={handleCopyTripShare}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Copy size={14} />
                <span>{copiedLink ? 'Link Copied!' : 'Copy Share Link'}</span>
              </button>
            </div>
          </div>

          {/* Trusted Emergency Contact Manager */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <UserCheck size={20} />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    Trusted Emergency Contact
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Automatically notified via SMS if SOS or destination alert triggers.
                  </p>
                </div>
              </div>

              {!editingContact && (
                <button
                  onClick={() => setEditingContact(true)}
                  className="text-xs font-bold text-blue-600 hover:underline"
                >
                  Edit Contact
                </button>
              )}
            </div>

            {editingContact ? (
              <form onSubmit={handleSaveContact} className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">Name</label>
                    <input
                      type="text"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">Phone Number</label>
                    <input
                      type="tel"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">Relationship</label>
                  <input
                    type="text"
                    value={contactRel}
                    onChange={(e) => setContactRel(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-600"
                    placeholder="e.g. Sister, Parent, Guardian"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingContact(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-blue-600"
                  >
                    Save Contact
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 flex justify-between items-center">
                <div>
                  <p className="font-extrabold text-sm text-slate-900">{userProfile.emergencyContact.name}</p>
                  <p className="text-xs text-slate-600 font-medium">
                    {userProfile.emergencyContact.phone} • <span className="text-emerald-700 font-bold">{userProfile.emergencyContact.relationship}</span>
                  </p>
                </div>

                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                  <CheckCircle2 size={13} /> Active Guardian
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Active Emergency Alerts & Incident Report Trigger */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Quick Problem Report Card */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <AlertTriangle size={18} className="text-amber-500" />
              <span>Report Transit Issue</span>
            </h3>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              Encountered bus delays, overcrowding, unsafe passenger behavior, or lost items? Submit an official report to transport control.
            </p>

            <button
              id="report-problem-trigger-btn"
              onClick={onOpenReportModal}
              className="w-full py-3 bg-slate-100 hover:bg-amber-50 hover:text-amber-900 hover:border-amber-300 text-slate-800 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <AlertTriangle size={14} className="text-amber-600" />
              <span>Submit Safety Report / Lost Item</span>
            </button>
          </div>

          {/* Safety Alert Log */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="font-extrabold text-sm text-slate-900 uppercase tracking-wider">
              Recent Safety Dispatches ({safetyAlerts.length})
            </h3>

            {safetyAlerts.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">
                No active SOS or emergency alerts triggered.
              </p>
            ) : (
              <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                {safetyAlerts.map((alert) => (
                  <div key={alert.id} className="p-3 bg-red-50 rounded-2xl border border-red-200 text-xs space-y-1">
                    <div className="flex justify-between items-center font-bold text-red-900">
                      <span>🚨 {alert.alertType} Alert</span>
                      <span className="text-[10px] font-mono text-red-700">{alert.timestamp}</span>
                    </div>
                    <p className="text-[11px] text-red-800">
                      📍 Location: {alert.location}
                    </p>
                    <p className="text-[10px] text-slate-500">
                      {alert.notes}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
