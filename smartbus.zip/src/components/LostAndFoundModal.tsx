import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PackageSearch, X, CheckCircle2, Send, Clock } from 'lucide-react';

interface LostAndFoundModalProps {
  onClose: () => void;
}

export const LostAndFoundModal: React.FC<LostAndFoundModalProps> = ({ onClose }) => {
  const { buses, submitLostItem, userProfile, lostItems } = useApp();

  const [busNumber, setBusNumber] = useState(buses[0]?.busNumber || '21G');
  const [journeyDate, setJourneyDate] = useState('Today');
  const [seatNumber, setSeatNumber] = useState('A12');
  const [item, setItem] = useState('');
  const [description, setDescription] = useState('');
  const [contactMethod, setContactMethod] = useState(userProfile.phone);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!item.trim() || !description.trim()) return;

    submitLostItem(busNumber, journeyDate, seatNumber, item, description, contactMethod);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 text-left">
        
        {/* Header */}
        <div className="bg-blue-600 text-white p-6 relative flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 text-blue-200 text-xs font-bold uppercase tracking-wider mb-1">
              <PackageSearch size={16} />
              <span>SmartBus Transit Lost Property</span>
            </div>
            <h2 className="text-xl font-black text-white">
              Report Lost & Found Item
            </h2>
            <p className="text-xs text-blue-100">
              Direct logging with depot conductors & vehicle cleaning inspectors
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition"
          >
            <X size={16} />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 size={32} />
            </div>
            <h3 className="text-xl font-black text-slate-900">Item Reported Successfully</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Depot staff for Bus <strong>{busNumber}</strong> have been alerted. You will receive an SMS if your <strong>{item}</strong> is secured at the terminal.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3.5 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-md"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Bus Number
                </label>
                <select
                  value={busNumber}
                  onChange={(e) => setBusNumber(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  {buses.map(b => (
                    <option key={b.id} value={b.busNumber}>Bus {b.busNumber}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Seat Number
                </label>
                <input
                  type="text"
                  value={seatNumber}
                  onChange={(e) => setSeatNumber(e.target.value)}
                  placeholder="e.g. A12"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                Item Name / Category
              </label>
              <input
                type="text"
                value={item}
                onChange={(e) => setItem(e.target.value)}
                placeholder="e.g., Black Leather Wallet, Water Bottle, Umbrella"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                Detailed Description / Distinguishing Marks
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe color, brand, contents, where you think it fell..."
                rows={2}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                Contact Phone
              </label>
              <input
                type="text"
                value={contactMethod}
                onChange={(e) => setContactMethod(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                required
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Send size={13} />
                <span>Submit Lost Item</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
