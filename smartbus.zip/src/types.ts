export type CrowdLevel = 'Low' | 'Medium' | 'High';
export type SeatStatus = 'AVAILABLE' | 'SELECTED' | 'BOOKED';
export type PaymentStatus = 'PENDING' | 'PAID' | 'FAILED';
export type BookingStatus = 'BOOKED' | 'BOARDED' | 'COMPLETED' | 'CANCELLED';
export type UserRole = 'passenger' | 'conductor' | 'admin';
export type SupportedLanguage = 'English' | 'Tamil' | 'Hindi';

export interface Stop {
  id: string;
  name: string;
  etaFromStart: number; // minutes
  lat: number;
  lng: number;
}

export interface CrowdPredictionSlot {
  time: string;
  crowdLevel: CrowdLevel;
  percentage: number;
  isRecommended?: boolean;
}

export interface Bus {
  id: string;
  busNumber: string;
  routeId: string;
  routeName: string;
  fromLocation: string;
  toLocation: string;
  currentLocation: string;
  currentStopIndex: number;
  nextStop: string;
  etaMinutes: number;
  crowdLevel: CrowdLevel;
  crowdPercentage: number;
  totalSeats: number;
  availableSeats: number;
  fare: number;
  status: 'On Time' | 'Delayed' | 'Departing Soon';
  stops: Stop[];
  crowdPredictions: CrowdPredictionSlot[];
  isElectric?: boolean;
  batteryPercentage?: number;
  wheelchairAccessible?: boolean;
  acType: 'AC' | 'Non-AC';
  safetyRating: number; // e.g. 4.9
}

export interface Seat {
  id: string;
  busId: string;
  seatNumber: string;
  row: string;
  col: number;
  isWindow: boolean;
  isWomenPriority?: boolean;
  status: SeatStatus;
}

export interface Booking {
  id: string;
  bookingId: string; // e.g. SB-2030-1001
  userId: string;
  passengerName: string;
  passengerPhone: string;
  passengerEmail: string;
  busId: string;
  busNumber: string;
  fromLocation: string;
  toLocation: string;
  seatNumber: string;
  fare: number;
  journeyDate: string;
  journeyTime: string;
  paymentStatus: PaymentStatus;
  bookingStatus: BookingStatus;
  createdAt: string;
  qrPayload: string;
  boardingVerifiedAt?: string;
  destinationAlertSet?: boolean;
  destinationStop?: string;
}

export interface TripHistory {
  id: string;
  busNumber: string;
  fromLocation: string;
  toLocation: string;
  date: string;
  fare: number;
  seatNumber: string;
  status: 'Completed' | 'Upcoming' | 'Cancelled';
  carbonSavedKg: number;
}

export interface SafetyAlert {
  id: string;
  userId: string;
  passengerName: string;
  busNumber?: string;
  bookingId?: string;
  alertType: 'SOS' | 'SAFETY_CHECK' | 'REPORT' | 'NIGHT_TRAVEL';
  location: string;
  timestamp: string;
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
  trustedContactNotified: boolean;
  notes?: string;
}

export interface SafetyReport {
  id: string;
  userId: string;
  busNumber: string;
  reportType: 'Bus Delay' | 'Overcrowding' | 'Unsafe Situation' | 'Seat Issue' | 'Route Issue' | 'Lost Item' | 'Other';
  description: string;
  contactMethod?: string;
  timestamp: string;
  status: 'PENDING' | 'UNDER_REVIEW' | 'RESOLVED';
}

export interface LostAndFoundItem {
  id: string;
  busNumber: string;
  journeyDate: string;
  seatNumber: string;
  item: string;
  description: string;
  contactMethod: string;
  status: 'Reported' | 'Under Investigation' | 'Found' | 'Claimed';
  reportedAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  preferredLanguage: 'English' | 'Tamil' | 'Hindi';
  accessibilityMode: boolean;
  highContrastMode: boolean;
  womenSafetyMode: boolean;
  shareTripByDefault: boolean;
}
