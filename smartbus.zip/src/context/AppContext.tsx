import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Bus, 
  Booking, 
  Seat, 
  TripHistory, 
  SafetyAlert, 
  SafetyReport, 
  LostAndFoundItem, 
  UserProfile, 
  SupportedLanguage 
} from '../types';
import { 
  INITIAL_BUSES, 
  INITIAL_PREBOOKED, 
  generateInitialSeatsForBus, 
  INITIAL_TRIP_HISTORY, 
  INITIAL_USER_PROFILE 
} from '../data/mockData';
import { translations } from '../translations';

interface SearchParams {
  from: string;
  to: string;
  date: string;
  time: string;
}

interface AppContextType {
  // Navigation & Active View
  activeView: 'home' | 'search' | 'live' | 'tickets' | 'trips' | 'safety' | 'women-safety' | 'conductor' | 'admin' | 'booking-flow';
  setActiveView: (view: 'home' | 'search' | 'live' | 'tickets' | 'trips' | 'safety' | 'women-safety' | 'conductor' | 'admin' | 'booking-flow') => void;
  
  // Language & Translation
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: typeof translations.English;

  // Profile & Accessibility
  userProfile: UserProfile;
  updateUserProfile: (profile: Partial<UserProfile>) => void;

  // Search & Results
  searchParams: SearchParams;
  setSearchParams: React.Dispatch<React.SetStateAction<SearchParams>>;
  filteredBuses: Bus[];
  performSearch: (from: string, to: string, date: string, time: string) => void;
  selectedBus: Bus | null;
  setSelectedBus: (bus: Bus | null) => void;

  // Buses & Seats State (Double booking prevention)
  buses: Bus[];
  busSeats: Record<string, Seat[]>;
  getSeatsForBus: (busId: string) => Seat[];
  bookSeat: (busId: string, seatNumber: string) => Promise<{ success: boolean; bookingId?: string; error?: string }>;
  
  // Active Booking Flow
  activeSelectedSeat: string | null;
  setActiveSelectedSeat: (seat: string | null) => void;
  lastConfirmedBooking: Booking | null;
  setLastConfirmedBooking: (b: Booking | null) => void;

  // Bookings & Tickets
  bookings: Booking[];
  myTrips: TripHistory[];
  
  // Conductor Operations
  verifyBookingById: (bookingId: string) => Booking | null;
  confirmBoarding: (bookingId: string) => boolean;

  // Safety Center & Women Safety
  safetyAlerts: SafetyAlert[];
  triggerSOS: (busNumber?: string, location?: string) => SafetyAlert;
  acknowledgeSafetyCheckIn: (isSafe: boolean) => void;
  isSafetyCheckInActive: boolean;
  setIsSafetyCheckInActive: (active: boolean) => void;
  
  // Destination Alert
  activeDestinationAlert: { busNumber: string; destination: string; stopsAway: number } | null;
  setDestinationAlert: (busNumber: string, destination: string) => void;
  dismissDestinationAlert: () => void;

  // Incident Reports & Lost & Found
  reports: SafetyReport[];
  submitReport: (busNumber: string, reportType: SafetyReport['reportType'], description: string, contactMethod?: string) => void;
  lostItems: LostAndFoundItem[];
  submitLostItem: (busNumber: string, date: string, seatNumber: string, item: string, description: string, contactMethod: string) => void;

  // Admin Dashboard CRUD
  addBus: (newBus: Omit<Bus, 'id' | 'crowdPredictions' | 'stops'>) => void;
  updateBus: (busId: string, updates: Partial<Bus>) => void;
  deleteBus: (busId: string) => void;

  // Feedback Toasts
  toastMessage: { text: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation
  const [activeView, setActiveView] = useState<'home' | 'search' | 'live' | 'tickets' | 'trips' | 'safety' | 'women-safety' | 'conductor' | 'admin' | 'booking-flow'>('home');

  // User Profile
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('smartbus_user');
    return saved ? JSON.parse(saved) : INITIAL_USER_PROFILE;
  });

  const language = userProfile.preferredLanguage || 'English';
  const t = translations[language] || translations.English;

  // Buses
  const [buses, setBuses] = useState<Bus[]>(() => {
    const saved = localStorage.getItem('smartbus_buses');
    return saved ? JSON.parse(saved) : INITIAL_BUSES;
  });

  // Seats map per bus
  const [busSeats, setBusSeats] = useState<Record<string, Seat[]>>(() => {
    const saved = localStorage.getItem('smartbus_seats');
    if (saved) return JSON.parse(saved);
    
    const initialMap: Record<string, Seat[]> = {};
    INITIAL_BUSES.forEach(b => {
      initialMap[b.id] = generateInitialSeatsForBus(b.id, INITIAL_PREBOOKED[b.id] || []);
    });
    return initialMap;
  });

  // Bookings list (with initial demo ticket)
  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('smartbus_bookings');
    if (saved) return JSON.parse(saved);
    
    return [
      {
        id: 'bk-demo-1',
        bookingId: 'SB-2030-1001',
        userId: 'usr-demo-101',
        passengerName: 'Harini Madesh',
        passengerPhone: '+91 98401 23456',
        passengerEmail: 'harini.demo@smartbus.gov.in',
        busId: 'bus-21g',
        busNumber: '21G',
        fromLocation: 'Tambaram',
        toLocation: 'Guindy',
        seatNumber: 'A12',
        fare: 20,
        journeyDate: 'Today',
        journeyTime: '06:35 PM',
        paymentStatus: 'PAID',
        bookingStatus: 'BOOKED',
        createdAt: new Date().toISOString(),
        qrPayload: 'SMARTBUS::SB-2030-1001::21G::A12::PAID',
        destinationAlertSet: true,
        destinationStop: 'Guindy'
      }
    ];
  });

  // Trips
  const [myTrips, setMyTrips] = useState<TripHistory[]>(() => {
    const saved = localStorage.getItem('smartbus_trips');
    return saved ? JSON.parse(saved) : INITIAL_TRIP_HISTORY;
  });

  // Search state
  const [searchParams, setSearchParams] = useState<SearchParams>({
    from: 'Tambaram',
    to: 'Guindy',
    date: new Date().toISOString().split('T')[0],
    time: '18:30'
  });

  const [filteredBuses, setFilteredBuses] = useState<Bus[]>(INITIAL_BUSES.filter(b => b.fromLocation === 'Tambaram' && b.toLocation === 'Guindy'));
  const [selectedBus, setSelectedBus] = useState<Bus | null>(INITIAL_BUSES[0]);
  const [activeSelectedSeat, setActiveSelectedSeat] = useState<string | null>(null);
  const [lastConfirmedBooking, setLastConfirmedBooking] = useState<Booking | null>(null);

  // Safety & alerts
  const [safetyAlerts, setSafetyAlerts] = useState<SafetyAlert[]>(() => {
    const saved = localStorage.getItem('smartbus_alerts');
    return saved ? JSON.parse(saved) : [];
  });
  const [isSafetyCheckInActive, setIsSafetyCheckInActive] = useState<boolean>(false);
  const [activeDestinationAlert, setActiveDestinationAlert] = useState<{ busNumber: string; destination: string; stopsAway: number } | null>(null);

  // Reports & Lost Items
  const [reports, setReports] = useState<SafetyReport[]>(() => {
    const saved = localStorage.getItem('smartbus_reports');
    return saved ? JSON.parse(saved) : [];
  });
  const [lostItems, setLostItems] = useState<LostAndFoundItem[]>(() => {
    const saved = localStorage.getItem('smartbus_lost');
    return saved ? JSON.parse(saved) : [];
  });

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('smartbus_user', JSON.stringify(userProfile));
    
    // Apply body classes for accessibility
    if (userProfile.accessibilityMode) {
      document.body.classList.add('accessibility-mode');
    } else {
      document.body.classList.remove('accessibility-mode');
    }

    if (userProfile.highContrastMode) {
      document.body.classList.add('high-contrast-mode');
    } else {
      document.body.classList.remove('high-contrast-mode');
    }
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('smartbus_buses', JSON.stringify(buses));
  }, [buses]);

  useEffect(() => {
    localStorage.setItem('smartbus_seats', JSON.stringify(busSeats));
  }, [busSeats]);

  useEffect(() => {
    localStorage.setItem('smartbus_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('smartbus_trips', JSON.stringify(myTrips));
  }, [myTrips]);

  useEffect(() => {
    localStorage.setItem('smartbus_alerts', JSON.stringify(safetyAlerts));
  }, [safetyAlerts]);

  useEffect(() => {
    localStorage.setItem('smartbus_reports', JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem('smartbus_lost', JSON.stringify(lostItems));
  }, [lostItems]);

  // Live simulation: periodic ETA tick & occasional movement for realism
  useEffect(() => {
    const interval = setInterval(() => {
      setBuses(prev => prev.map(bus => {
        // Minor dynamic fluctuation for demo
        const newEta = bus.etaMinutes > 1 ? bus.etaMinutes - 0.2 : (bus.stops.length * 5);
        return {
          ...bus,
          etaMinutes: Math.max(1, Math.round(newEta * 10) / 10)
        };
      }));
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  // Language updater
  const setLanguage = (newLang: SupportedLanguage) => {
    setUserProfile(prev => ({ ...prev, preferredLanguage: newLang }));
    showToast(`Language changed to ${newLang}`, 'info');
  };

  const updateUserProfile = (profile: Partial<UserProfile>) => {
    setUserProfile(prev => ({ ...prev, ...profile }));
    showToast('Profile updated successfully', 'success');
  };

  // Perform search with intelligent matching
  const performSearch = (from: string, to: string, date: string, time: string) => {
    setSearchParams({ from, to, date, time });
    
    // Filter matching routes or return related buses
    const exact = buses.filter(b => 
      (b.fromLocation.toLowerCase().includes(from.toLowerCase()) || b.stops.some(s => s.name.toLowerCase().includes(from.toLowerCase()))) &&
      (b.toLocation.toLowerCase().includes(to.toLowerCase()) || b.stops.some(s => s.name.toLowerCase().includes(to.toLowerCase())))
    );

    if (exact.length > 0) {
      setFilteredBuses(exact);
      setSelectedBus(exact[0]);
    } else {
      // Fallback show all buses with updated from/to indication
      setFilteredBuses(buses);
      if (buses.length > 0) setSelectedBus(buses[0]);
    }
  };

  const getSeatsForBus = (busId: string): Seat[] => {
    if (!busSeats[busId]) {
      const generated = generateInitialSeatsForBus(busId, INITIAL_PREBOOKED[busId] || []);
      setBusSeats(prev => ({ ...prev, [busId]: generated }));
      return generated;
    }
    return busSeats[busId];
  };

  // Double Booking Prevention Lock
  const bookSeat = async (busId: string, seatNumber: string): Promise<{ success: boolean; bookingId?: string; error?: string }> => {
    const currentSeats = busSeats[busId] || getSeatsForBus(busId);
    const targetSeat = currentSeats.find(s => s.seatNumber === seatNumber);

    if (!targetSeat) {
      return { success: false, error: 'Invalid seat number.' };
    }

    if (targetSeat.status === 'BOOKED') {
      return { 
        success: false, 
        error: 'This seat was just booked by another passenger. Please choose another seat.' 
      };
    }

    // Atomic update simulation (Guarantees no double booking)
    const targetBus = buses.find(b => b.id === busId);
    if (!targetBus) return { success: false, error: 'Bus not found.' };

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newBookingId = `SB-2030-${randomSuffix}`;

    const newBooking: Booking = {
      id: `bk-${Date.now()}`,
      bookingId: newBookingId,
      userId: userProfile.id,
      passengerName: userProfile.name,
      passengerPhone: userProfile.phone,
      passengerEmail: userProfile.email,
      busId: targetBus.id,
      busNumber: targetBus.busNumber,
      fromLocation: targetBus.fromLocation,
      toLocation: targetBus.toLocation,
      seatNumber: seatNumber,
      fare: targetBus.fare,
      journeyDate: searchParams.date || 'Today',
      journeyTime: targetBus.status === 'Departing Soon' ? 'Departing in 5m' : `${targetBus.etaMinutes} mins away`,
      paymentStatus: 'PAID',
      bookingStatus: 'BOOKED',
      createdAt: new Date().toISOString(),
      qrPayload: `SMARTBUS::${newBookingId}::${targetBus.busNumber}::${seatNumber}::PAID`,
      destinationAlertSet: true,
      destinationStop: targetBus.toLocation
    };

    // Update seats state
    setBusSeats(prev => ({
      ...prev,
      [busId]: (prev[busId] || currentSeats).map(s => 
        s.seatNumber === seatNumber ? { ...s, status: 'BOOKED' } : s
      )
    }));

    // Update bus available seats count
    setBuses(prev => prev.map(b => 
      b.id === busId ? { ...b, availableSeats: Math.max(0, b.availableSeats - 1) } : b
    ));

    // Update bookings list
    setBookings(prev => [newBooking, ...prev]);
    setLastConfirmedBooking(newBooking);

    // Also record into myTrips
    const newTrip: TripHistory = {
      id: `tr-${Date.now()}`,
      busNumber: targetBus.busNumber,
      fromLocation: targetBus.fromLocation,
      toLocation: targetBus.toLocation,
      date: 'Today, Just Booked',
      fare: targetBus.fare,
      seatNumber: seatNumber,
      status: 'Upcoming',
      carbonSavedKg: 1.6
    };
    setMyTrips(prev => [newTrip, ...prev]);

    // Destination alert preset
    if (userProfile.womenSafetyMode) {
      setTimeout(() => {
        setIsSafetyCheckInActive(true);
      }, 12000);
    }

    return { success: true, bookingId: newBookingId };
  };

  // Conductor functions
  const verifyBookingById = (bookingId: string): Booking | null => {
    const cleanId = bookingId.trim().toUpperCase();
    const found = bookings.find(b => b.bookingId.toUpperCase() === cleanId || b.id === cleanId);
    return found || null;
  };

  const confirmBoarding = (bookingId: string): boolean => {
    let updated = false;
    setBookings(prev => prev.map(b => {
      if (b.bookingId === bookingId || b.id === bookingId) {
        updated = true;
        return { 
          ...b, 
          bookingStatus: 'BOARDED', 
          boardingVerifiedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
        };
      }
      return b;
    }));

    if (updated) {
      showToast(`Passenger Boarding Confirmed for ${bookingId} ✅`, 'success');
    }
    return updated;
  };

  // Safety triggers
  const triggerSOS = (busNumber = '21G', location = 'Chromepet GST Road'): SafetyAlert => {
    const alertId = `SOS-${Date.now()}`;
    const newAlert: SafetyAlert = {
      id: alertId,
      userId: userProfile.id,
      passengerName: userProfile.name,
      busNumber,
      bookingId: lastConfirmedBooking?.bookingId || 'SB-2030-1001',
      alertType: 'SOS',
      location,
      timestamp: new Date().toLocaleTimeString(),
      status: 'ACTIVE',
      trustedContactNotified: true,
      notes: `Simulated Emergency Alert. SMS & GPS location dispatched to ${userProfile.emergencyContact.name} (${userProfile.emergencyContact.phone}).`
    };

    setSafetyAlerts(prev => [newAlert, ...prev]);
    showToast('🚨 SOS Activated! Emergency contacts notified with live coordinates.', 'error');
    return newAlert;
  };

  const acknowledgeSafetyCheckIn = (isSafe: boolean) => {
    setIsSafetyCheckInActive(false);
    if (isSafe) {
      showToast('Glad you are safe! Safe travels.', 'success');
    } else {
      triggerSOS('Active Bus', 'Approaching Destination');
    }
  };

  const setDestinationAlert = (busNumber: string, destination: string) => {
    setActiveDestinationAlert({
      busNumber,
      destination,
      stopsAway: 2
    });
    showToast(`Destination Alert activated for ${destination} (2 stops away notification enabled)`, 'success');
  };

  const dismissDestinationAlert = () => {
    setActiveDestinationAlert(null);
  };

  // Reports
  const submitReport = (busNumber: string, reportType: SafetyReport['reportType'], description: string, contactMethod?: string) => {
    const newReport: SafetyReport = {
      id: `rep-${Date.now()}`,
      userId: userProfile.id,
      busNumber,
      reportType,
      description,
      contactMethod: contactMethod || userProfile.phone,
      timestamp: new Date().toLocaleString(),
      status: 'PENDING'
    };
    setReports(prev => [newReport, ...prev]);
    showToast('Report submitted successfully. Control room notified.', 'success');
  };

  const submitLostItem = (busNumber: string, date: string, seatNumber: string, item: string, description: string, contactMethod: string) => {
    const newLostItem: LostAndFoundItem = {
      id: `lost-${Date.now()}`,
      busNumber,
      journeyDate: date,
      seatNumber,
      item,
      description,
      contactMethod,
      status: 'Reported',
      reportedAt: new Date().toLocaleString()
    };
    setLostItems(prev => [newLostItem, ...prev]);
    showToast('Lost & Found item ticket created. Depots will be inspected.', 'success');
  };

  // Admin CRUD
  const addBus = (newBusData: Omit<Bus, 'id' | 'crowdPredictions' | 'stops'>) => {
    const newId = `bus-${newBusData.busNumber.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`;
    const newBus: Bus = {
      ...newBusData,
      id: newId,
      currentStopIndex: 0,
      stops: [
        { id: 'st-custom-1', name: newBusData.fromLocation, etaFromStart: 0, lat: 12.9249, lng: 80.1278 },
        { id: 'st-custom-2', name: 'Intermediate Junction', etaFromStart: 12, lat: 12.9675, lng: 80.1491 },
        { id: 'st-custom-3', name: newBusData.toLocation, etaFromStart: 25, lat: 13.0067, lng: 80.2023 }
      ],
      crowdPredictions: [
        { time: '06:00 PM', crowdLevel: 'Medium', percentage: 50 },
        { time: '06:30 PM', crowdLevel: 'High', percentage: 75 },
        { time: '07:00 PM', crowdLevel: 'Low', percentage: 30, isRecommended: true }
      ]
    };

    setBuses(prev => [newBus, ...prev]);
    setBusSeats(prev => ({
      ...prev,
      [newId]: generateInitialSeatsForBus(newId, [])
    }));
    showToast(`Bus ${newBus.busNumber} added successfully to active fleet!`, 'success');
  };

  const updateBus = (busId: string, updates: Partial<Bus>) => {
    setBuses(prev => prev.map(b => b.id === busId ? { ...b, ...updates } : b));
    showToast('Bus details updated successfully', 'success');
  };

  const deleteBus = (busId: string) => {
    setBuses(prev => prev.filter(b => b.id !== busId));
    showToast('Bus removed from fleet', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        activeView,
        setActiveView,
        language,
        setLanguage,
        t,
        userProfile,
        updateUserProfile,
        searchParams,
        setSearchParams,
        filteredBuses,
        performSearch,
        selectedBus,
        setSelectedBus,
        buses,
        busSeats,
        getSeatsForBus,
        bookSeat,
        activeSelectedSeat,
        setActiveSelectedSeat,
        lastConfirmedBooking,
        setLastConfirmedBooking,
        bookings,
        myTrips,
        verifyBookingById,
        confirmBoarding,
        safetyAlerts,
        triggerSOS,
        acknowledgeSafetyCheckIn,
        isSafetyCheckInActive,
        setIsSafetyCheckInActive,
        activeDestinationAlert,
        setDestinationAlert,
        dismissDestinationAlert,
        reports,
        submitReport,
        lostItems,
        submitLostItem,
        addBus,
        updateBus,
        deleteBus,
        toastMessage,
        showToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
