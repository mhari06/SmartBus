import { Bus, Seat, TripHistory, UserProfile } from '../types';

export const LOCATIONS = [
  'Tambaram',
  'Chromepet',
  'Pallavaram',
  'Guindy',
  'Saidapet',
  'T Nagar',
  'Egmore',
  'Chennai Central',
  'Besant Nagar',
  'Vadapalani',
  'Adyar',
  'Koyambedu'
];

export const INITIAL_BUSES: Bus[] = [
  {
    id: 'bus-21g',
    busNumber: '21G',
    routeId: 'route-tb-gd',
    routeName: 'Tambaram ⇄ Guindy (Via GST Road)',
    fromLocation: 'Tambaram',
    toLocation: 'Guindy',
    currentLocation: 'Chromepet',
    currentStopIndex: 1,
    nextStop: 'Pallavaram',
    etaMinutes: 6,
    crowdLevel: 'Medium',
    crowdPercentage: 65,
    totalSeats: 28,
    availableSeats: 12,
    fare: 20,
    status: 'On Time',
    acType: 'Non-AC',
    isElectric: true,
    batteryPercentage: 78,
    wheelchairAccessible: true,
    safetyRating: 4.9,
    stops: [
      { id: 'st-1', name: 'Tambaram Sanatorium', etaFromStart: 0, lat: 12.9249, lng: 80.1278 },
      { id: 'st-2', name: 'Chromepet', etaFromStart: 4, lat: 12.9516, lng: 80.1462 },
      { id: 'st-3', name: 'Pallavaram', etaFromStart: 10, lat: 12.9675, lng: 80.1491 },
      { id: 'st-4', name: 'Meenambakkam Metro', etaFromStart: 16, lat: 12.9878, lng: 80.1764 },
      { id: 'st-5', name: 'Guindy Kathipara Junction', etaFromStart: 24, lat: 13.0067, lng: 80.2023 }
    ],
    crowdPredictions: [
      { time: '05:30 PM', crowdLevel: 'Medium', percentage: 55 },
      { time: '06:00 PM', crowdLevel: 'High', percentage: 88 },
      { time: '06:30 PM', crowdLevel: 'High', percentage: 92 },
      { time: '07:00 PM', crowdLevel: 'Medium', percentage: 65 },
      { time: '07:30 PM', crowdLevel: 'Low', percentage: 35, isRecommended: true },
      { time: '08:00 PM', crowdLevel: 'Low', percentage: 25 }
    ]
  },
  {
    id: 'bus-5e',
    busNumber: '5E',
    routeId: 'route-tb-gd-exp',
    routeName: 'Tambaram ⇄ Guindy (Superfast Express)',
    fromLocation: 'Tambaram',
    toLocation: 'Guindy',
    currentLocation: 'Saidapet Approach',
    currentStopIndex: 2,
    nextStop: 'Guindy Kathipara',
    etaMinutes: 2,
    crowdLevel: 'Low',
    crowdPercentage: 30,
    totalSeats: 28,
    availableSeats: 21,
    fare: 20,
    status: 'On Time',
    acType: 'AC',
    isElectric: true,
    batteryPercentage: 92,
    wheelchairAccessible: true,
    safetyRating: 5.0,
    stops: [
      { id: 'st-1', name: 'Tambaram', etaFromStart: 0, lat: 12.9249, lng: 80.1278 },
      { id: 'st-3', name: 'Pallavaram Flyover', etaFromStart: 7, lat: 12.9675, lng: 80.1491 },
      { id: 'st-5', name: 'Guindy Kathipara', etaFromStart: 18, lat: 13.0067, lng: 80.2023 }
    ],
    crowdPredictions: [
      { time: '05:30 PM', crowdLevel: 'Low', percentage: 30, isRecommended: true },
      { time: '06:00 PM', crowdLevel: 'Medium', percentage: 48 },
      { time: '06:30 PM', crowdLevel: 'Medium', percentage: 52 },
      { time: '07:00 PM', crowdLevel: 'Low', percentage: 28, isRecommended: true },
      { time: '07:30 PM', crowdLevel: 'Low', percentage: 20 },
      { time: '08:00 PM', crowdLevel: 'Low', percentage: 15 }
    ]
  },
  {
    id: 'bus-18a',
    busNumber: '18A',
    routeId: 'route-tb-cc',
    routeName: 'Tambaram ⇄ Chennai Central (Via Anna Salai)',
    fromLocation: 'Tambaram',
    toLocation: 'Chennai Central',
    currentLocation: 'Saidapet',
    currentStopIndex: 3,
    nextStop: 'T Nagar Nandanam',
    etaMinutes: 8,
    crowdLevel: 'High',
    crowdPercentage: 88,
    totalSeats: 28,
    availableSeats: 4,
    fare: 30,
    status: 'Delayed',
    acType: 'Non-AC',
    isElectric: false,
    wheelchairAccessible: false,
    safetyRating: 4.8,
    stops: [
      { id: 'st-1', name: 'Tambaram', etaFromStart: 0, lat: 12.9249, lng: 80.1278 },
      { id: 'st-2', name: 'Chromepet', etaFromStart: 6, lat: 12.9516, lng: 80.1462 },
      { id: 'st-5', name: 'Guindy', etaFromStart: 20, lat: 13.0067, lng: 80.2023 },
      { id: 'st-6', name: 'Saidapet', etaFromStart: 26, lat: 13.0213, lng: 80.2231 },
      { id: 'st-7', name: 'T Nagar', etaFromStart: 34, lat: 13.0418, lng: 80.2341 },
      { id: 'st-8', name: 'Chennai Central', etaFromStart: 50, lat: 13.0827, lng: 80.2707 }
    ],
    crowdPredictions: [
      { time: '05:30 PM', crowdLevel: 'High', percentage: 80 },
      { time: '06:00 PM', crowdLevel: 'High', percentage: 95 },
      { time: '06:30 PM', crowdLevel: 'High', percentage: 90 },
      { time: '07:00 PM', crowdLevel: 'High', percentage: 85 },
      { time: '07:30 PM', crowdLevel: 'Medium', percentage: 60 },
      { time: '08:00 PM', crowdLevel: 'Low', percentage: 40 }
    ]
  },
  {
    id: 'bus-21d',
    busNumber: '21D',
    routeId: 'route-tb-eg',
    routeName: 'Tambaram ⇄ Egmore Railway Station',
    fromLocation: 'Tambaram',
    toLocation: 'Egmore',
    currentLocation: 'Pallavaram',
    currentStopIndex: 2,
    nextStop: 'Guindy',
    etaMinutes: 14,
    crowdLevel: 'Medium',
    crowdPercentage: 60,
    totalSeats: 28,
    availableSeats: 16,
    fare: 25,
    status: 'On Time',
    acType: 'AC',
    isElectric: true,
    batteryPercentage: 84,
    wheelchairAccessible: true,
    safetyRating: 4.9,
    stops: [
      { id: 'st-1', name: 'Tambaram', etaFromStart: 0, lat: 12.9249, lng: 80.1278 },
      { id: 'st-3', name: 'Pallavaram', etaFromStart: 8, lat: 12.9675, lng: 80.1491 },
      { id: 'st-5', name: 'Guindy', etaFromStart: 22, lat: 13.0067, lng: 80.2023 },
      { id: 'st-9', name: 'DMS Metro', etaFromStart: 35, lat: 13.0450, lng: 80.2480 },
      { id: 'st-10', name: 'Egmore Station', etaFromStart: 45, lat: 13.0784, lng: 80.2609 }
    ],
    crowdPredictions: [
      { time: '05:30 PM', crowdLevel: 'Low', percentage: 38 },
      { time: '06:00 PM', crowdLevel: 'Medium', percentage: 60 },
      { time: '06:30 PM', crowdLevel: 'High', percentage: 78 },
      { time: '07:00 PM', crowdLevel: 'Medium', percentage: 55 },
      { time: '07:30 PM', crowdLevel: 'Low', percentage: 32, isRecommended: true },
      { time: '08:00 PM', crowdLevel: 'Low', percentage: 22 }
    ]
  },
  {
    id: 'bus-27b',
    busNumber: '27B',
    routeId: 'route-cp-tn',
    routeName: 'Chromepet ⇄ T Nagar (Express Way)',
    fromLocation: 'Chromepet',
    toLocation: 'T Nagar',
    currentLocation: 'Pallavaram Station',
    currentStopIndex: 1,
    nextStop: 'Guindy Industrial Estate',
    etaMinutes: 11,
    crowdLevel: 'Low',
    crowdPercentage: 25,
    totalSeats: 28,
    availableSeats: 22,
    fare: 20,
    status: 'Departing Soon',
    acType: 'AC',
    isElectric: true,
    batteryPercentage: 95,
    wheelchairAccessible: true,
    safetyRating: 5.0,
    stops: [
      { id: 'st-2', name: 'Chromepet', etaFromStart: 0, lat: 12.9516, lng: 80.1462 },
      { id: 'st-3', name: 'Pallavaram', etaFromStart: 5, lat: 12.9675, lng: 80.1491 },
      { id: 'st-5', name: 'Guindy Estate', etaFromStart: 18, lat: 13.0067, lng: 80.2023 },
      { id: 'st-7', name: 'T Nagar Bus Stand', etaFromStart: 30, lat: 13.0418, lng: 80.2341 }
    ],
    crowdPredictions: [
      { time: '05:30 PM', crowdLevel: 'Low', percentage: 25, isRecommended: true },
      { time: '06:00 PM', crowdLevel: 'Low', percentage: 35 },
      { time: '06:30 PM', crowdLevel: 'Medium', percentage: 50 },
      { time: '07:00 PM', crowdLevel: 'Low', percentage: 30 },
      { time: '07:30 PM', crowdLevel: 'Low', percentage: 18 }
    ]
  }
];

export const generateInitialSeatsForBus = (busId: string, preBooked: string[] = []): Seat[] => {
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const seats: Seat[] = [];

  rows.forEach((rowLetter) => {
    for (let col = 1; col <= 4; col++) {
      const seatNum = `${rowLetter}${col}`;
      const isBooked = preBooked.includes(seatNum);
      const isWomenPriority = rowLetter === 'A' || rowLetter === 'B'; // Front rows reserved/preferred for women
      const isWindow = col === 1 || col === 4;

      seats.push({
        id: `${busId}-${seatNum}`,
        busId,
        seatNumber: seatNum,
        row: rowLetter,
        col,
        isWindow,
        isWomenPriority,
        status: isBooked ? 'BOOKED' : 'AVAILABLE'
      });
    }
  });

  return seats;
};

export const INITIAL_PREBOOKED: Record<string, string[]> = {
  'bus-21g': ['A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'C1', 'C3', 'D2', 'D4', 'E1', 'F3', 'G1', 'G2', 'G3', 'G4'],
  'bus-5e': ['A1', 'A2', 'B3', 'C1', 'E4', 'G2', 'G3'],
  'bus-18a': ['A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4', 'D1', 'D2', 'D3', 'D4', 'E1', 'E2', 'E3', 'E4', 'F1', 'F2', 'F3', 'F4'],
  'bus-21d': ['A1', 'A3', 'B2', 'B4', 'C2', 'C4', 'D1', 'E2', 'E3', 'F1', 'G3', 'G4'],
  'bus-27b': ['A1', 'B2', 'C3', 'D4', 'E1', 'G2']
};

export const INITIAL_TRIP_HISTORY: TripHistory[] = [
  {
    id: 'tr-1',
    busNumber: '21G',
    fromLocation: 'Tambaram',
    toLocation: 'Guindy',
    date: 'Yesterday, 6:40 PM',
    fare: 20,
    seatNumber: 'A12',
    status: 'Completed',
    carbonSavedKg: 1.8
  },
  {
    id: 'tr-2',
    busNumber: '5E',
    fromLocation: 'Saidapet',
    toLocation: 'Guindy',
    date: '3 days ago, 8:15 AM',
    fare: 20,
    seatNumber: 'B4',
    status: 'Completed',
    carbonSavedKg: 1.2
  },
  {
    id: 'tr-3',
    busNumber: '18A',
    fromLocation: 'Tambaram',
    toLocation: 'Chennai Central',
    date: 'Last week, 5:30 PM',
    fare: 30,
    seatNumber: 'C2',
    status: 'Completed',
    carbonSavedKg: 2.9
  }
];

export const INITIAL_USER_PROFILE: UserProfile = {
  id: 'usr-demo-101',
  name: 'Harini Madesh',
  phone: '+91 98401 23456',
  email: 'harini.demo@smartbus.gov.in',
  emergencyContact: {
    name: 'Ananya (Sister)',
    phone: '+91 98400 98765',
    relationship: 'Family Member'
  },
  preferredLanguage: 'English',
  accessibilityMode: false,
  highContrastMode: false,
  womenSafetyMode: true,
  shareTripByDefault: true
};
